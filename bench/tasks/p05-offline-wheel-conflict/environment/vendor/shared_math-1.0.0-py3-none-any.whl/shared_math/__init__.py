def scale(value):
    return value * 10
