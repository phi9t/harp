//! Controller-owned native runtime registry. Journal commits precede external effects.
use crate::{
    Controller, db,
    native_ws::NativeWs,
    supervisor::{self, Binding},
};
use rusqlite::{OptionalExtension, params};
use serde::Deserialize;
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    fs,
    io::{BufRead, BufReader, Write},
    os::unix::net::UnixStream,
    path::{Path, PathBuf},
    sync::Mutex,
    time::Duration,
};
use uuid::Uuid;
const SCHEMA: &str = "e587a3d5ffab12e528589e14d385b04d1192b9ae6914ce008cd3ea507e5aa455";
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    schema_migration: String,
    topology: String,
    transport_root: PathBuf,
    servers: Vec<Server>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Server {
    id: String,
    supervisor_socket: PathBuf,
    auth_ref: String,
    transport_root: PathBuf,
    worker_supervisor_socket: PathBuf,
    worker_auth_ref: String,
    worker_transport_root: PathBuf,
    schema_digest: String,
}
struct Connected {
    incarnation: String,
    ws: NativeWs,
}
pub struct CodexRuntime {
    config: Config,
    connections: Mutex<HashMap<String, Connected>>,
}
fn text<'a>(v: &'a Value, key: &str) -> Result<&'a str, String> {
    v[key]
        .as_str()
        .ok_or_else(|| format!("native {key} missing"))
}
fn secret(reference: &str) -> Result<String, String> {
    if reference.is_empty()
        || !reference
            .bytes()
            .all(|b| b.is_ascii_uppercase() || b == b'_' || b.is_ascii_digit())
    {
        return Err("native auth reference refused".into());
    }
    let value = std::env::var(reference).map_err(|_| "native auth reference unavailable")?;
    if value.len() < 12 {
        return Err("native private credential required".into());
    }
    Ok(value)
}
impl CodexRuntime {
    pub fn open(path: &Path, controller: &Controller) -> Result<Self, String> {
        let config: Config = serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
        if config.schema_migration != "1-to-2"
            || !matches!(config.topology.as_str(), "shared" | "separate")
        {
            return Err("explicit Codex schema migration/topology required".into());
        }
        if !config.transport_root.is_absolute() || config.transport_root.starts_with("/usr") {
            return Err("private native transport root required".into());
        }
        fs::create_dir_all(&config.transport_root).map_err(|e| e.to_string())?;
        if config
            .transport_root
            .canonicalize()
            .map_err(|e| e.to_string())?
            != config.transport_root
        {
            return Err("native transport aliases refused".into());
        }
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&config.transport_root, fs::Permissions::from_mode(0o700))
            .map_err(|e| e.to_string())?;
        if config.servers.len() > 1 {
            return Err("one configured native profile required".into());
        }
        for s in &config.servers {
            if s.id.is_empty()
                || s.schema_digest != SCHEMA
                || s.transport_root != config.transport_root
                || !s.supervisor_socket.is_absolute()
                || !s.worker_supervisor_socket.is_absolute()
                || !s.worker_transport_root.is_absolute()
            {
                return Err("native registered profile refused".into());
            }
            secret(&s.auth_ref)?;
            secret(&s.worker_auth_ref)?;
            if std::env::var_os("CORENIUS_SUPERVISOR_SOCKET").map(PathBuf::from)
                != Some(s.worker_supervisor_socket.clone())
                || s.worker_auth_ref != "CORENIUS_SUPERVISOR_TOKEN"
            {
                return Err("native worker effect owner mismatch".into());
            }
        }
        let mut c = controller
            .connection
            .lock()
            .map_err(|_| "controller lock poisoned")?;
        let version: i64 = db(c.pragma_query_value(None, "user_version", |r| r.get(0)))?;
        if version == 1 {
            let tx = db(c.transaction())?;
            db(tx.execute_batch(include_str!("codex_schema.sql")))?;
            db(tx.commit())?
        } else if version != 2 {
            return Err("Codex registry schema unsupported".into());
        }
        Ok(Self {
            config,
            connections: Mutex::new(HashMap::new()),
        })
    }
    pub fn drain(&self, controller: &Controller) -> Result<(), String> {
        let Some(server) = self.config.servers.first() else {
            return Ok(());
        };
        let rows = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let mut stmt=db(c.prepare("SELECT a.id,a.project,a.scope_epoch,a.base,a.brief,a.cancel_requested,a.state,o.id,b.body FROM attempts a JOIN operations o ON o.attempt=a.id AND o.kind='start' JOIN briefs b ON b.id=a.brief WHERE a.state<>'exited'"))?;
            let rows = db(stmt.query_map([], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, i64>(2)?,
                    r.get::<_, String>(3)?,
                    r.get::<_, String>(4)?,
                    r.get::<_, i64>(5)?,
                    r.get::<_, String>(6)?,
                    r.get::<_, String>(7)?,
                    r.get::<_, String>(8)?,
                ))
            }))?;
            rows.collect::<rusqlite::Result<Vec<_>>>()
                .map_err(|e| e.to_string())?
        };
        for (attempt, project, epoch, base, brief, cancelled, state, operation, body) in rows {
            if cancelled != 0 || state != "running" {
                continue;
            }
            let binding = Binding {
                project: project.clone(),
                attempt: attempt.clone(),
                operation,
                scope_epoch: epoch,
                base,
                brief,
            };
            if let Err(error) = self.bind_worker(controller, server, &binding, &body) {
                eprintln!("native reconcile {attempt}: {error}");
            }
        }
        Ok(())
    }
    fn bind_worker(
        &self,
        controller: &Controller,
        server: &Server,
        worker: &Binding,
        body: &str,
    ) -> Result<(), String> {
        let executor = supervisor::native_lookup(
            &server.worker_supervisor_socket,
            &secret(&server.worker_auth_ref)?,
            worker,
        )?;
        if executor["runtime"]["kind"] != "exec"
            || executor["runtime"]["endpoint"]
                != json!(
                    server
                        .worker_transport_root
                        .join(&worker.attempt)
                        .join("native.sock")
                )
        {
            return Err("registered executor endpoint mismatch".into());
        }
        let id = format!("worker:{}:{}", worker.attempt, worker.scope_epoch);
        let mut document = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let prior: Option<String> = db(c
                .query_row(
                    "SELECT document FROM codex_bindings WHERE id=?1",
                    [&id],
                    |r| r.get(0),
                )
                .optional())?;
            match prior {
                Some(raw) => serde_json::from_str(&raw).map_err(|e| e.to_string())?,
                None => {
                    let value = json!({"server_id":if self.config.topology=="shared"{server.id.clone()}else{format!("{}:{}",server.id,worker.attempt)},"executor":executor["runtime"],"executor_execution":executor["execution"],"ui_input_ready":false});
                    db(c.execute(
                        "INSERT INTO codex_bindings VALUES(?1,?2,'attempt',?3,?4,?5,'preparing')",
                        params![
                            id,
                            worker.project,
                            worker.attempt,
                            worker.scope_epoch,
                            value.to_string()
                        ],
                    ))?;
                    value
                }
            }
        };
        if document["executor_execution"]["handle"] != executor["execution"]["handle"]
            || document["executor"]["workspace_identity"]
                != executor["runtime"]["workspace_identity"]
        {
            return Err("durable executor binding mismatch".into());
        }
        let server_id = text(&document, "server_id")?.to_string();
        let app_binding = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let raw: Option<String> = db(c
                .query_row(
                    "SELECT document FROM codex_servers WHERE id=?1",
                    [&server_id],
                    |r| r.get(0),
                )
                .optional())?;
            if let Some(raw) = raw {
                let value: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
                serde_json::from_value(value["effect_binding"].clone())
                    .map_err(|e| e.to_string())?
            } else {
                let binding = Binding {
                    project: worker.project.clone(),
                    attempt: if self.config.topology == "shared" {
                        Uuid::new_v4().to_string()
                    } else {
                        worker.attempt.clone()
                    },
                    operation: Uuid::new_v4().to_string(),
                    scope_epoch: worker.scope_epoch,
                    base: worker.base.clone(),
                    brief: worker.brief.clone(),
                };
                let value = json!({"effect_binding":binding,"profile":server.id,"schema_digest":server.schema_digest,"auth_ref":server.auth_ref,"topology":self.config.topology});
                db(c.execute(
                    "INSERT INTO codex_servers VALUES(?1,?2,'prepared')",
                    params![server_id, value.to_string()],
                ))?;
                binding
            }
        };
        let token = secret(&server.auth_ref)?;
        let execution =
            match supervisor::call(&server.supervisor_socket, &token, "lookup", &app_binding)? {
                Some(e) => e,
                None => supervisor::call(&server.supervisor_socket, &token, "start", &app_binding)?
                    .ok_or("native server effect absent")?,
            };
        if execution.state != "running" {
            return Err("native server effect not live".into());
        }
        let app = supervisor::native_lookup(&server.supervisor_socket, &token, &app_binding)?;
        if app["runtime"]["kind"] != "app"
            || app["runtime"]["endpoint"]
                != json!(
                    server
                        .transport_root
                        .join(&app_binding.attempt)
                        .join("native.sock")
                )
            || app["runtime"]["own_executor_only"] != json!(self.config.topology == "separate")
        {
            return Err("native server profile/topology mismatch".into());
        }
        let incarnation = text(&app["runtime"], "incarnation")?;
        if document["server_incarnation"] != incarnation {
            document["ui_input_ready"] = json!(false);
            self.save_binding(controller, &id, &document, "reconciling")?;
        }
        let mut connections = self
            .connections
            .lock()
            .map_err(|_| "native connection lock poisoned")?;
        if connections
            .get(&server_id)
            .is_none_or(|v| v.incarnation != incarnation)
        {
            let mut ws = NativeWs::connect(
                Path::new(text(&app["runtime"], "endpoint")?),
                text(&app, "capability")?,
                text(&app["runtime"], "runtime_start")?,
            )?;
            let ready=ws.rpc("initialize",json!({"clientInfo":{"name":"corenius-controller","version":"0.1.0"},"capabilities":{"experimentalApi":true}}))?;
            if !text(&ready, "userAgent")?.contains("0.159.3") {
                return Err("native initialize version mismatch".into());
            }
            ws.notify("initialized", json!({}))?;
            connections.insert(
                server_id.clone(),
                Connected {
                    incarnation: incarnation.into(),
                    ws,
                },
            );
        }
        let ws = &mut connections.get_mut(&server_id).unwrap().ws;
        let result = self.configure_thread(
            controller,
            &id,
            &mut document,
            ws,
            &app,
            &executor,
            worker,
            body,
        );
        if result.is_err() {
            connections.remove(&server_id);
        }
        result
    }
    fn save_binding(
        &self,
        controller: &Controller,
        id: &str,
        document: &Value,
        state: &str,
    ) -> Result<(), String> {
        let c = controller
            .connection
            .lock()
            .map_err(|_| "controller lock poisoned")?;
        db(c.execute(
            "UPDATE codex_bindings SET document=?2,state=?3 WHERE id=?1",
            params![id, document.to_string(), state],
        ))?;
        Ok(())
    }
    fn mutation(
        &self,
        controller: &Controller,
        id: &str,
        project: &str,
        kind: &str,
        intent: &Value,
        ws: &mut NativeWs,
    ) -> Result<Value, String> {
        let operation = Uuid::new_v4().to_string();
        {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            db(c.execute(
                "INSERT INTO codex_operations VALUES(?1,?2,?3,?4,'applying',?5,NULL)",
                params![operation, project, id, kind, intent.to_string()],
            ))?;
        }
        let result = ws.rpc(kind, intent.clone());
        {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let (state, observation) = match &result {
                Ok(value) => ("confirmed", value.clone()),
                Err(error) => ("unknown", json!({"error":error})),
            };
            db(c.execute(
                "UPDATE codex_operations SET state=?2,observation=?3 WHERE id=?1",
                params![operation, state, observation.to_string()],
            ))?;
        }
        result
    }
    fn configure_thread(
        &self,
        controller: &Controller,
        id: &str,
        document: &mut Value,
        ws: &mut NativeWs,
        app: &Value,
        executor: &Value,
        worker: &Binding,
        body: &str,
    ) -> Result<(), String> {
        let incarnation = text(&app["runtime"], "incarnation")?;
        if document["server_incarnation"] != incarnation
            || document["executor"]["incarnation"] != executor["runtime"]["incarnation"]
        {
            let mut stream = UnixStream::connect(text(&app["runtime"], "control_endpoint")?)
                .map_err(|e| e.to_string())?;
            stream
                .set_read_timeout(Some(Duration::from_secs(1)))
                .map_err(|e| e.to_string())?;
            writeln!(stream,"{}",json!({"token":app["capability"],"action":"executor_bridge","attempt":worker.attempt})).map_err(|e|e.to_string())?;
            let mut reply = String::new();
            BufReader::new(stream)
                .read_line(&mut reply)
                .map_err(|e| e.to_string())?;
            let reply: Value = serde_json::from_str(&reply).map_err(|e| e.to_string())?;
            let url = format!(
                "{}/?corenius_start={}",
                text(&reply["ok"], "url")?,
                text(&executor["runtime"], "runtime_start")?
            );
            let environment_id = format!(
                "executor-{}-{}",
                worker.attempt,
                text(&executor["runtime"], "runtime_start")?
            );
            // Plaintext native capability remains transport-only, never enters intent/observation storage.
            let safe = json!({"environmentId":environment_id,"execServerUrl":url,"auth_ref":executor["runtime"]["auth_ref"],"executor_incarnation":executor["runtime"]["incarnation"]});
            let op = Uuid::new_v4().to_string();
            {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.execute("INSERT INTO codex_operations VALUES(?1,?2,?3,'environment/add','applying',?4,NULL)",params![op,worker.project,id,safe.to_string()]))?;
            }
            let added=ws.rpc("environment/add",json!({"environmentId":environment_id,"execServerUrl":url,"authBearerToken":executor["capability"],"connectTimeoutMs":1500}));
            {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.execute(
                    "UPDATE codex_operations SET state=?2,observation=?3 WHERE id=?1",
                    params![
                        op,
                        if added.is_ok() {
                            "confirmed"
                        } else {
                            "unknown"
                        },
                        json!({"registered":added.is_ok()}).to_string()
                    ],
                ))?;
            }
            added?;
            document["environment_id"] = json!(environment_id);
            document["server_incarnation"] = json!(incarnation);
            document["server_store"] = app["runtime"]["store_id"].clone();
            document["server_execution"] = app["execution"].clone();
            document["executor"] = executor["runtime"].clone();
            self.save_binding(controller, id, document, "remote_registered")?;
        }
        let status = ws.rpc(
            "environment/status",
            json!({"environmentId":document["environment_id"]}),
        )?;
        if status["status"] != "ready" {
            return Err(format!("remote executor not ready: {status}"));
        }
        let environments = json!([{"environmentId":document["environment_id"],"cwd":"/workspace","runtimeWorkspaceRoots":["/workspace"]}]);
        if document["thread_id"].is_null() {
            let prior_unknown = {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.query_row("SELECT COUNT(*) FROM codex_operations WHERE binding=?1 AND kind='thread/start' AND state<>'confirmed'",[id],|r|r.get::<_,i64>(0)))?
            };
            if prior_unknown != 0 {
                return Err("thread creation acknowledgement unknown; no replay".into());
            }
            let result=self.mutation(controller,id,&worker.project,"thread/start",&json!({"model":"gpt-6-sol","modelProvider":"corenius-relay","cwd":"/workspace","approvalPolicy":"never","sandbox":"danger-full-access","environments":environments}),ws)?;
            document["thread_id"] = result["thread"]["id"].clone();
            if document["thread_id"].as_str().is_none() {
                return Err("native thread identity missing".into());
            }
            self.save_binding(controller, id, document, "thread_bound")?;
        }
        if document["turn_id"].is_null() {
            let prior_unknown = {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.query_row("SELECT COUNT(*) FROM codex_operations WHERE binding=?1 AND kind='turn/start' AND state<>'confirmed'",[id],|r|r.get::<_,i64>(0)))?
            };
            if prior_unknown != 0 {
                return Err("turn acknowledgement unknown; no replay".into());
            }
            let result=self.mutation(controller,id,&worker.project,"turn/start",&json!({"threadId":document["thread_id"],"clientUserMessageId":Uuid::new_v4().to_string(),"input":[{"type":"text","text":body,"text_elements":[]}],"environments":environments}),ws)?;
            document["turn_id"] = result["turn"]["id"].clone();
            if document["turn_id"].as_str().is_none() {
                return Err("native turn identity missing".into());
            }
            self.save_binding(controller, id, document, "turn_bound")?;
        }
        let observed = ws.rpc(
            "thread/read",
            json!({"threadId":document["thread_id"],"includeTurns":true}),
        )?;
        document["observed_environments"] = observed["thread"]["environments"].clone();
        document["ui_input_ready"] = json!(observed["thread"]["environments"] == environments);
        document["native_activity"] = json!(ws.take_events());
        self.save_binding(controller, id, document, "bound")?;
        {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let value = json!({"effect_binding":app["execution"]["binding"],"execution":app["execution"],"runtime":app["runtime"],"schema_digest":SCHEMA,"topology":self.config.topology});
            db(c.execute(
                "UPDATE codex_servers SET document=?2,state='qualified' WHERE id=?1",
                params![document["server_id"].as_str(), value.to_string()],
            ))?;
        }
        Ok(())
    }
}
