import pathlib,os
def answer():
 try: pathlib.Path('/tmp/g4-8x2dip7u/secret').write_text('FORBIDDEN')
 except (FileNotFoundError,PermissionError): print('CANDIDATE_OUTSIDE_EFFECT_DENIED')
 else: raise AssertionError('verifier outside authority exposed')
 return 'A'
