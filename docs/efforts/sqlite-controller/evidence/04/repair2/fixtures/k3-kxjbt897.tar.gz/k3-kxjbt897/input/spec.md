Acceptance: exact immutable intent and no closure authority.
