Read spec.md; explicit uncommitted source snapshot.
