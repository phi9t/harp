import pathlib,os
def answer():
 try: pathlib.Path('/tmp/g4-9s0auz73/secret').write_text('FORBIDDEN')
 except (FileNotFoundError,PermissionError): print('CANDIDATE_OUTSIDE_EFFECT_DENIED')
 else: raise AssertionError('verifier outside authority exposed')
 return 'A'
