Changed external acceptance is a proposal.
