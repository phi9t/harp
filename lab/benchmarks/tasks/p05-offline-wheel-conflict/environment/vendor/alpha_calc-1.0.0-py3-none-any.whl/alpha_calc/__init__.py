from shared_math import scale

def alpha_score(value):
    return scale(value) + 1
