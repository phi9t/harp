"""MODEL_FREE_ACTUAL_PROTOCOL: real controller/supervisor/Codex/companion/tools.
The harness only admits/cancels through the controller, observes owned resources,
and supplies deterministic local Responses SSE bytes. It never dispatches workers.
"""
import pathlib,tempfile,json,subprocess,socket,hashlib,time,sys,threading,http.server,socketserver,os
from wsutil import WS
BIN=pathlib.Path('/data02/home/philip.yang/.codex/packages/standalone/releases/0.159.3-x86_64-unknown-linux-musl/bin')
HERE=pathlib.Path(__file__).resolve().parents[2]
ORIGIN=pathlib.Path('/data02/home/philip.yang/devx/tmp/corenius-sqlite-topology-sms522gg')
TOKEN='operator-registry-secret'; SUPERVISOR='native-executor-secret'; CONTROL='native-controlplane-secret'
SCHEMA='e587a3d5ffab12e528589e14d385b04d1192b9ae6914ce008cd3ea507e5aa455'
def pin(path):return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def request(path,value):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(35);s.connect(str(path));s.sendall(json.dumps(value).encode()+b'\n');return json.loads(s.makefile('rb').readline())
def wait(predicate,seconds=20):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  result=predicate()
  if result:return result
  time.sleep(.04)
 raise AssertionError('behavior deadline')
class UnixHTTP(socketserver.ThreadingMixIn,socketserver.UnixStreamServer):daemon_threads=True
class Owned:
 def __init__(self,r):self.r=r;self.processes=[];self.records=[]
 def spawn(self,args,name,env):
  p=subprocess.Popen(args,env=env,stdout=open(self.r/(name+'.stdout'),'w'),stderr=open(self.r/(name+'.stderr'),'w'))
  self.processes.append(p);self.records.append({'name':name,'pid':p.pid,'start_stat':pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text(),'argv':args});return p
 def stop(self):
  for p in reversed(self.processes):
   if p.poll() is None:p.kill()
   p.wait(timeout=5)
  for record,p in zip(self.records,self.processes):record['exit']=p.returncode
  print('owned_fixture_resources',json.dumps(self.records),flush=True)

def run(topology):
 with tempfile.TemporaryDirectory(prefix='cnr-',dir='/tmp') as directory:
  r=pathlib.Path(directory);owned=Owned(r);release=threading.Event();counts={};counter_lock=threading.Lock();requests=[]
  for name in ['workers','controlplanes','t-exec','t-app','canonical']:(r/name).mkdir()
  (r/'canonical/protected').write_text('never mounted')
  guard=socket.socket();guard.bind(('127.0.0.1',0));guard.listen();guard_port=guard.getsockname()[1]
  class Handler(http.server.BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    assert self.path=='/v1/responses',self.path
    value=json.loads(self.rfile.read(int(self.headers['Content-Length'])));requests.append(value)
    text=json.dumps(value.get('input',[]));group='TASK_A' if 'TASK_A' in text else 'TASK_B' if 'TASK_B' in text else 'LEAD'
    assert release.wait(60),'fixture model response release deadline'
    with counter_lock:n=counts.get(group,0)+1;counts[group]=n
    item={'type':'message','id':f'msg-{group}-{n}','role':'assistant','content':[{'type':'output_text','text':'MODEL_FREE_FIXTURE_DONE'}]}
    if group!='LEAD' and n%3==1:
     probe=f"import pathlib,os,socket,json; w=pathlib.Path('/workspace'); forbidden={json.dumps([str(r),str(r/'controller.sock'),str(r/'state.db'),str(r/'canonical'),str(r/'controlplanes'),str(r/'workers/native-authority'),'/home/philip.yang','/root/.ssh'])}; assert all(not pathlib.Path(p).exists() for p in forbidden); s=socket.socket(); s.settimeout(.1); assert s.connect_ex(('127.0.0.1',{guard_port}))!=0; status=pathlib.Path('/proc/self/status').read_text(); assert 'CapEff:\\t0000000000000000' in status; (w/'{group}-shell').write_text('actual_native_shell'); (w/'{group}-shell-{n}').write_text('actual_native_shell'); (w/'{group}-probe').write_text(json.dumps({{'pid_namespace':os.readlink('/proc/self/ns/pid'),'net_namespace':os.readlink('/proc/self/ns/net'),'host_and_authority_absent':True,'host_tcp_blocked':True}}))"
     cmd='/usr/bin/python3 -c '+__import__('shlex').quote(probe)
     code='text(await tools.exec_command('+json.dumps({'cmd':cmd,'workdir':'/workspace','max_output_tokens':1000})+'));'
     item={'type':'custom_tool_call','id':f'ct-{group}-{n}','call_id':f'call-{group}-{n}','name':'exec','namespace':'functions','input':code}
    elif group!='LEAD' and n%3==2:
     patch='*** Begin Patch\n*** Add File: /workspace/'+group+'-patch-'+str(n)+'\n+actual_native_patch\n*** End Patch'
     code='text(await tools.apply_patch('+json.dumps(patch)+'));'
     item={'type':'custom_tool_call','id':f'ct-{group}-{n}','call_id':f'call-{group}-{n}','name':'exec','namespace':'functions','input':code}
    response=f'response-{group}-{n}';events=[{'type':'response.created','response':{'id':response,'status':'in_progress'}},{'type':'response.output_item.done','output_index':0,'item':item},{'type':'response.completed','response':{'id':response,'status':'completed','output':[item],'usage':{'input_tokens':1,'output_tokens':1,'total_tokens':2}}}]
    body=''.join('data: '+json.dumps(event)+'\n\n' for event in events).encode();self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  provider=UnixHTTP(str(r/'provider.sock'),Handler);threading.Thread(target=provider.serve_forever,daemon=True).start()
  cfg=r/'runtime.toml';cfg.write_text((ORIGIN/'codex/config.toml').read_text().replace(str(ORIGIN/'catalog.json'),'/run/codex/catalog.json').replace('35361','8777'))
  assets={'binary':pin(BIN/'codex'),'companion':pin(BIN/'codex-code-mode-host'),'catalog':pin(ORIGIN/'catalog.json'),'config':pin(cfg),'launcher':pin(HERE/'support/codex_insula.py')}
  supervisor=pathlib.Path(sys.argv[1]).parent/'corenius-attempt-supervisor'
  try:
   for root,transport,kind,secret in [('workers','t-exec','exec',SUPERVISOR),('controlplanes','t-app','app',CONTROL)]:
    profile=dict(assets,kind=kind,transport_root=str(r/transport))
    if kind=='app':profile.update(provider_socket=str(r/'provider.sock'),executor_root=str(r/'t-exec'),own_executor_only=topology=='separate')
    config=r/(root+'.json');config.write_text(json.dumps({'root':str(r/root),'profile':{'executable':'/usr/bin/python3','args':['/run/codex/launcher.py'],'codex':profile}}))
    process=owned.spawn([str(supervisor),str(config),str(r/(root+'.sock'))],root,{'CORENIUS_SUPERVISOR_TOKEN':secret,'PATH':'/usr/bin:/bin'})
    def ready():
     assert process.poll() is None,(r/(root+'.stderr')).read_text()
     return (r/(root+'.sock')).exists()
    wait(ready,30)
   runtime_config=r/'controller-native.json';runtime_config.write_text(json.dumps({'schema_migration':'1-to-2','topology':topology,'transport_root':str(r/'t-app'),'servers':[{'id':'native','supervisor_socket':str(r/'controlplanes.sock'),'auth_ref':'CONTROLPLANE_SECRET','transport_root':str(r/'t-app'),'worker_supervisor_socket':str(r/'workers.sock'),'worker_auth_ref':'CORENIUS_SUPERVISOR_TOKEN','worker_transport_root':str(r/'t-exec'),'schema_digest':SCHEMA}]}))
   env={'PATH':'/usr/bin:/bin','CORENIUS_OPERATOR_TOKEN':TOKEN,'CORENIUS_CODEX_CONFIG':str(runtime_config),'CORENIUS_SUPERVISOR_SOCKET':str(r/'workers.sock'),'CORENIUS_SUPERVISOR_TOKEN':SUPERVISOR,'CONTROLPLANE_SECRET':CONTROL,'CORENIUS_TEST_LOSE_NATIVE_ACK':str(r/'lose-ack'),'CORENIUS_TEST_HOLD_CODEX':str(r/'hold-codex')}
   controller=owned.spawn([sys.argv[1],str(r/'state.db'),str(r/'controller.sock')],'controller',env)
   def startup():
    assert controller.poll() is None,(r/'controller.stderr').read_text()
    return (r/'controller.sock').exists()
   wait(startup)
   auth={'principal':'operator','token':TOKEN}
   def query(kind):
    value=request(r/'controller.sock',{'auth':auth,'project':'p','query':{'kind':kind,'args':{}}});assert 'ok' in value,value;return value['ok']
   def command(kind,args):
    for retry in range(8):
     rev=0 if kind=='create_project' else query('snapshot')['revision']
     value=request(r/'controller.sock',{'auth':auth,'project':'p','command':{'kind':kind,'args':args,'expected_revision':rev,'idempotency_key':str(__import__('uuid').uuid4())}})
     if 'ok' in value:return value['ok']['result']
     assert 'revision' in value.get('error',''),value
    raise AssertionError('command revision contention')
   command('create_project',{'name':'p','base':'0123456789abcdef0123456789abcdef01234567'})
   grants=[]
   for task in ['TASK_A','TASK_B']:
    command('create_task',{'task':task,'work_ref':{'deployment':'fixture','project':'p','item':task},'source_revision':'r1','brief':task+' MODEL_FREE_ACTUAL_PROTOCOL'})
    grants.append(command('admit',{'task':task}))
   def bound():
    registry=query('codex_registry')
    return registry if len(registry['bindings'])==2 and all(b['document'].get('thread_id') for b in registry['bindings']) else False
   registry=wait(bound,30)
   assert query('snapshot')['occupied_slots']==2
   print('actual_bound_registry',topology,json.dumps(registry),flush=True)
   first=registry['bindings'][0];before_ops=len(registry['operations'])
   for forbidden in [{'thread_id':'foreign'},{'server_id':'foreign'},{'history':[]},{'path':'/host'},{'environment_id':'local'},{'workspace':'/host'}]:
    value=request(r/'controller.sock',{'auth':auth,'project':'p','command':{'kind':'codex_turn','args':dict({'attempt':first['attempt'],'text':'forged'},**forbidden),'expected_revision':query('snapshot')['revision'],'idempotency_key':str(__import__('uuid').uuid4())}})
    assert 'error' in value,value
   for binding_guard in [{'thread_id':'foreign'},{'server_store':'foreign'},{'server_incarnation':'foreign'},{'environment_id':'local'}]:
    value=request(r/'controller.sock',{'auth':auth,'project':'p','command':{'kind':'codex_turn','args':{'attempt':first['attempt'],'text':'forged','expected_binding':binding_guard},'expected_revision':query('snapshot')['revision'],'idempotency_key':str(__import__('uuid').uuid4())}})
    assert 'error' in value,value
   worker_auth={'principal':grants[0]['principal'],'token':grants[0]['token']}
   value=request(r/'controller.sock',{'auth':worker_auth,'project':'p','command':{'kind':'codex_turn','args':{'attempt':first['attempt'],'text':'forged'},'expected_revision':query('snapshot')['revision'],'idempotency_key':str(__import__('uuid').uuid4())}})
   assert 'error' in value,value
   assert len(query('codex_registry')['operations'])==before_ops
   valid=command('codex_steer',{'attempt':first['attempt'],'text':'TASK_A MODEL_FREE_CURRENT_TURN_STEER','expected_turn':first['document']['turn_id']})
   wait(lambda:any(o['id']==valid['operation'] and o['state']=='confirmed' for o in query('codex_registry')['operations']))
   print('native_current_authority_and_selector_guards',topology,flush=True)
   if os.environ.get('CORENIUS_TEST_DISCONNECT_FIXTURE')=='1':
    (r/'hold-codex').write_text('declared test-only controller adaptation hold')
    import signal
    executor=registry['bindings'][0]['document']['executor'];descriptor=os.pidfd_open(executor['runtime_pid'])
    try:
     stat=pathlib.Path('/proc/'+str(executor['runtime_pid'])+'/stat').read_text().rsplit(') ',1)[1].split()
     assert stat[19]==executor['runtime_start'];signal.pidfd_send_signal(descriptor,signal.SIGKILL)
    finally:os.close(descriptor)
    def child_restarted():
     path=r/'workers'/registry['bindings'][0]['attempt']/'scratch/native-runtime.json'
     return json.loads(path.read_text())['start_ticks']!=executor['runtime_start']
    wait(child_restarted)
    release.set();time.sleep(2)
    app_doc=next(s['document'] for s in registry['servers'] if s['id']==registry['bindings'][0]['document']['server_id']);runtime=app_doc['runtime']
    cap=(r/'controlplanes/native-authority'/app_doc['effect_binding']['attempt']).read_text()
    observer=WS.connect('127.0.0.1',8788,token=cap,unix=runtime['endpoint'],path='/?corenius_start='+runtime['runtime_start'])
    def observe(method,params,identifier):
     observer.send({'id':identifier,'method':method,'params':params})
     while True:
      response=observer.recv()
      if response.get('id')==identifier:return response
    observe('initialize',{'clientInfo':{'name':'corenius_readonly_fixture_observer','version':'0.1'},'capabilities':{'experimentalApi':True}},'observer-init')
    status=observe('environment/status',{'environmentId':registry['bindings'][0]['document']['environment_id']},'observer-status');assert status['result']['status']=='disconnected',status
    observation=observe('thread/read',{'threadId':registry['bindings'][0]['document']['thread_id'],'includeTurns':True},'observer-thread')
    assert observation['result']['thread']['environments'][0]['environmentId']==registry['bindings'][0]['document']['environment_id'],observation
    observer.close();print('native_disconnected_status',topology,json.dumps(status),flush=True)
    workspace=r/'workers'/registry['bindings'][0]['attempt']/'workspace'
    assert not (workspace/'TASK_A-shell').exists() and not any(workspace.glob('TASK_A-patch-*'))
    assert not any((p/'TASK_A-shell').exists() or list(p.glob('TASK_A-patch-*')) for p in (r/'controlplanes').glob('*/workspace'))
    print('native_disconnected_remote_no_local_fallback',topology,flush=True)
    (r/'hold-codex').unlink()
    wait(lambda:next(b['document'] for b in query('codex_registry')['bindings'] if b['attempt']==registry['bindings'][0]['attempt'])['executor']['incarnation']!=executor['incarnation'])
    stopped=command('codex_interrupt',{'attempt':registry['bindings'][0]['attempt'],'expected_turn':registry['bindings'][0]['document']['turn_id']})
    wait(lambda:any(o['id']==stopped['operation'] and o['state']=='confirmed' for o in query('codex_registry')['operations']))
    with counter_lock:counts['TASK_A']=3
    restored=command('codex_turn',{'attempt':registry['bindings'][0]['attempt'],'text':'TASK_A MODEL_FREE_EXECUTOR_RECOVERY'})
    wait(lambda:any(o['id']==restored['operation'] and o['state']=='confirmed' for o in query('codex_registry')['operations']))
    wait(lambda:(workspace/'TASK_A-shell-4').exists() and (workspace/'TASK_A-patch-5').exists())
    print('native_owned_executor_rebound',topology,flush=True)
    for grant in grants:command('cancel_attempt',{'attempt':grant['attempt']})
    wait(lambda:query('snapshot')['occupied_slots']==0)
    return
   release.set()
   for grant,task in zip(grants,['TASK_A','TASK_B']):
    workspace=r/'workers'/grant['attempt']/'workspace'
    wait(lambda:(workspace/(task+'-shell')).exists() and any(workspace.glob(task+'-patch-*')),20)
    assert not any((workspace/(peer+'-shell')).exists() for peer in ['TASK_A','TASK_B'] if peer!=task)
    print('actual_native_effects',topology,task,(workspace/(task+'-probe')).read_text(),flush=True)
   # Controller connection restart must reconnect subscriptions without new threads/turns.
   durable=query('codex_registry');controller.kill();controller.wait(timeout=5)
   restarted_env=dict(env)
   if os.environ.get('CORENIUS_TEST_RETARGET_FIXTURE')=='1':
    changed=json.loads(runtime_config.read_text());changed['topology']='separate' if topology=='shared' else 'shared'
    changed_config=r/'retarget.json';changed_config.write_text(json.dumps(changed));restarted_env['CORENIUS_CODEX_CONFIG']=str(changed_config)
   controller=owned.spawn([sys.argv[1],str(r/'state.db'),str(r/'controller.sock')],'controller-restarted',restarted_env)
   if os.environ.get('CORENIUS_TEST_RETARGET_FIXTURE')=='1':
    deadline=time.monotonic()+3
    while time.monotonic()<deadline and controller.poll() is None:time.sleep(.03)
    assert controller.poll() is not None and controller.returncode!=0,'durable native topology/config identity must refuse retargeted startup'
    print('durable_native_retarget_refused',topology,flush=True)
    return
   def reconnect():
    assert controller.poll() is None,(r/'controller-restarted.stderr').read_text()
    try:return request(r/'controller.sock',{'auth':auth,'project':'p','query':{'kind':'codex_registry','args':{}}}).get('ok')
    except (ConnectionRefusedError,FileNotFoundError):return False
   wait(reconnect)
   after=query('codex_registry')
   assert [b['document']['thread_id'] for b in after['bindings']]==[b['document']['thread_id'] for b in durable['bindings']]
   assert query('snapshot')['occupied_slots']==2
   print('controller_native_connection_reconciled',topology,flush=True)
   # Only owned fixture processes are killed; the controller remains the dispatcher.
   before=query('codex_registry'); old=before['bindings'][0]['document']; app=next(s for s in before['servers'] if s['id']==old['server_id'])['document']['runtime']
   import signal
   native_pid=app['runtime_pid']; descriptor=os.pidfd_open(native_pid)
   try:
    stat=pathlib.Path('/proc/'+str(native_pid)+'/stat').read_text().rsplit(') ',1)[1].split()
    assert stat[19]==app['runtime_start']
    signal.pidfd_send_signal(descriptor,signal.SIGKILL)
   finally:os.close(descriptor)
   def resumed():
    row=next(b for b in query('codex_registry')['bindings'] if b['document']['thread_id']==old['thread_id'])
    d=row['document']
    return d if d.get('server_incarnation')!=old['server_incarnation'] and d.get('recovery_state')=='remote_registered_input_blocked' else False
   recovered=wait(resumed,20)
   assert recovered['server_store']==old['server_store'] and recovered['executor_execution']['handle']==old['executor_execution']['handle'] and not recovered['ui_input_ready']
   new=command('codex_turn',{'attempt':before['bindings'][0]['attempt'],'text':'TASK_A MODEL_FREE_RESTART_RESTORATION','expected_binding':{'thread_id':old['thread_id'],'server_store':old['server_store']}})
   wait(lambda:any(o['id']==new['operation'] and o['state']=='confirmed' for o in query('codex_registry')['operations']))
   restored=wait(lambda:next((b['document'] for b in query('codex_registry')['bindings'] if b['document']['thread_id']==old['thread_id'] and b['document']['ui_input_ready'] and b['document']['turn_id']!=old['turn_id']),False))
   recovered_workspace=r/'workers'/before['bindings'][0]['attempt']/'workspace'
   wait(lambda:(recovered_workspace/'TASK_A-shell-4').exists() and (recovered_workspace/'TASK_A-patch-5').exists(),20)
   print('native_restart_restored',topology,json.dumps({'thread_id':restored['thread_id'],'server_store':restored['server_store'],'server_incarnation_changed':True,'remote_restored':True}),flush=True)
   if os.environ.get('CORENIUS_TEST_ACK_FIXTURE')=='1':
    (r/'lose-ack').write_text('declared test-only acknowledgement loss')
    lost=command('codex_turn',{'attempt':before['bindings'][0]['attempt'],'text':'TASK_A MODEL_FREE_LOST_ACK'})
    wait(lambda:(r/'lose-ack.observed').exists())
    history_printed=False
    def acknowledged():
     nonlocal history_printed
     projection=query('codex_registry');operation=next(o for o in projection['operations'] if o['id']==lost['operation'])
     if operation['state']=='unknown' and not history_printed:
      print('actual_unknown_turn_history',topology,json.dumps(projection['bindings'][0]['document'].get('native_turns')),flush=True);history_printed=True
     return operation if operation['state']=='confirmed' and operation['observation'].get('reconciled_from_native_history') else False
    reconciled=wait(acknowledged,20)
    assert reconciled['observation']['turn_id']!=restored['turn_id']
    print('native_lost_ack_reconciled',topology,json.dumps(reconciled),flush=True)
   lead=command('replace_lead',{})
   wait(lambda:any(b['role']=='lead' and b['document'].get('thread_id') for b in query('codex_registry')['bindings']))
   assert query('snapshot')['occupied_slots']==2
   print('native_lead_no_worker_slot',topology,flush=True)
   for grant in grants:command('cancel_attempt',{'attempt':grant['attempt']})
   wait(lambda:query('snapshot')['occupied_slots']==0)
   retired=query('codex_registry')
   wait(lambda:all(b['state']=='revoked' and not b['document']['ui_input_ready'] for b in query('codex_registry')['bindings'] if b['role']=='attempt'))
   print('controller_owned_cancellation_confirmed',topology,flush=True)
  finally:
   release.set();owned.stop();provider.shutdown();provider.server_close();guard.close()
   for log in list(r.glob('*.stderr'))+list(r.glob('*/**/output.log')):
    if log.stat().st_size:print('owned_log',log.name,log.read_text()[-3000:],flush=True)
for topology in ['shared','separate']:run(topology)
