use corenius_sqlite_controller::Controller;
use serde_json::json;
use std::process::Command;

#[test]
fn native_registry_is_a_durable_authenticated_controller_projection() {
    let native = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_init.py"
        ))
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&native.stdout));
    assert!(
        native.status.success(),
        "{}",
        String::from_utf8_lossy(&native.stderr)
    );
    let root = tempfile::tempdir().unwrap();
    let controller =
        Controller::open(root.path().join("state.db"), "operator-registry-secret").unwrap();
    let registry = controller.handle(json!({"auth":{"principal":"operator","token":"operator-registry-secret"},"project":"registry","query":{"kind":"codex_registry","args":{}}}));
    assert!(
        registry.is_ok(),
        "qualified native registry projection must exist: {registry:?}"
    );
    let refused = controller.handle(json!({"auth":{"principal":"operator","token":"wrong"},"project":"registry","query":{"kind":"codex_registry","args":{}}}));
    assert!(refused.is_err());
}

#[test]
fn configured_native_topologies_are_isolated_and_controller_owned() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn pinned_native_services_use_supervised_private_network_profiles() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_profile.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
#[cfg(feature = "fault-injection")]
fn actual_native_turn_ack_loss_reconciles_without_replay() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .env("CORENIUS_TEST_ACK_FIXTURE", "1")
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn durable_native_configuration_refuses_retargeted_topology() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .env("CORENIUS_TEST_RETARGET_FIXTURE", "1")
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
#[cfg(feature = "fault-injection")]
fn disconnected_native_executor_refuses_fallback_and_rebinds_owned_realm() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .env("CORENIUS_TEST_DISCONNECT_FIXTURE", "1")
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
#[cfg(feature = "fault-injection")]
fn durable_native_confirmation_survives_crash_before_binding_adoption() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .env("CORENIUS_TEST_CONFIRM_FIXTURE", "1")
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn configured_native_daemon_refuses_missing_runtime_configuration() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .env("CORENIUS_TEST_RETARGET_FIXTURE", "1")
        .env("CORENIUS_TEST_RETARGET_KIND", "missing")
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn native_registry_projects_capabilities_and_scoped_typed_turns() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .env("CORENIUS_TEST_PROJECTION_FIXTURE", "1")
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[cfg(feature = "fault-injection")]
#[test]
fn unknown_native_start_refuses_new_turn_until_reconciled() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .env("CORENIUS_TEST_ACK_FIXTURE", "1")
        .env("CORENIUS_TEST_ACK_FENCE_FIXTURE", "1")
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}
