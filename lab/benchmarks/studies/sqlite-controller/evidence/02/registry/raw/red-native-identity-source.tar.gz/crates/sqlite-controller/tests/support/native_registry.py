"""Real native registry/topology public fixture. No model/production credentials."""
import pathlib,tempfile,json,subprocess,socket,hashlib,time,sys
BIN=pathlib.Path('/data02/home/philip.yang/.codex/packages/standalone/releases/0.159.3-x86_64-unknown-linux-musl/bin')
HERE=pathlib.Path(__file__).resolve().parents[2]
def pin(path):return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def request(path,value):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(5);s.connect(str(path));s.sendall(json.dumps(value).encode()+b'\n');line=s.makefile('rb').readline();return json.loads(line)
def wait(predicate,seconds=10):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  result=predicate()
  if result:return result
  time.sleep(.025)
 raise AssertionError('behavior deadline')
# The fixture is expanded slice-by-slice after the public configured-mode RED.
with tempfile.TemporaryDirectory(prefix='cnr-',dir='/tmp') as directory:
 r=pathlib.Path(directory);config=r/'controller-native.json'
 config.write_text(json.dumps({'schema_migration':'1-to-2','topology':'shared','transport_root':str(r/'transport'),'servers':[]}))
 p=subprocess.Popen([sys.argv[1],str(r/'state.db'),str(r/'controller.sock')],env={'PATH':'/usr/bin:/bin','CORENIUS_OPERATOR_TOKEN':'operator-registry-secret','CORENIUS_CODEX_CONFIG':str(config)},stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  def ready():
   assert p.poll() is None, p.stderr.read()
   try:
    answer=request(r/'controller.sock',{'auth':{'principal':'operator','token':'operator-registry-secret'},'project':'registry','query':{'kind':'codex_registry','args':{}}})
    assert answer.get('ok',{}).get('configured') is True, 'native configured mode must enable durable registry: '+str(answer)
    return answer
   except (FileNotFoundError,ConnectionRefusedError):return False
  print('configured_registry',wait(ready),flush=True)
 finally:p.kill();p.wait(timeout=5)
