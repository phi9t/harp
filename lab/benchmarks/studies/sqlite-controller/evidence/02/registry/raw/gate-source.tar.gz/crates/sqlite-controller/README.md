# Local SQLite controller

Standalone storage and deterministic supervised runtime baseline; no PostgreSQL
or Temporal dependency or service. Build and
run from this directory, or pass `--manifest-path crates/sqlite-controller/Cargo.toml`.

```sh
cargo test --locked --offline --features fault-injection
cargo build --locked --offline
mkdir -m 700 /tmp/corenius-private
# Set a retained random CORENIUS_OPERATOR_TOKEN through your secret handling.
./target/debug/corenius-sqlite-controller /tmp/corenius-private/state.db /tmp/corenius-private/api.sock
```

The database directory must already exist on persistent supported local storage
outside all worker mounts. Database, WAL, shared memory, socket and lifetime lock
are controller-owned. The lock file is never removed; OS ownership ends on exit.
Dangling database symlinks are refused before creating a target. Existing symlink
aliases resolve to the same canonical lock; database hard links are unsupported.
Do not run the daemon with the `fault-injection` feature in normal operation.
That explicit test build supports a pre-COMMIT admission barrier, not a runtime effect.

Send one newline-delimited JSON request per Unix socket connection. Socket reading
and response writing share a one-second total transport deadline; an expired
connection closes. Retry an unacknowledged mutation with its original key. Replies are
`{"ok": VALUE}` or `{"error": "DESCRIPTION"}`. The library exposes the same
`Controller::open(path, bootstrap_secret)` and `Controller::handle(JSON)` seam.
The operator principal is `operator`; the secret initializes it once and must
match on reopen. No token rotation or historical-state import is implicit.

```python
import json, os, socket
request = {
    "auth": {"principal": "operator", "token": os.environ["CORENIUS_OPERATOR_TOKEN"]},
    "project": "demo",
    "command": {
        "kind": "create_project", "expected_revision": 0,
        "idempotency_key": "project-demo",
        "args": {"name": "demo", "base": "0123456789abcdef0123456789abcdef01234567"},
    },
}
with socket.socket(socket.AF_UNIX) as s:
    s.connect("/tmp/corenius-private/api.sock")
    s.sendall((json.dumps(request) + "\n").encode())
    print(s.makefile().readline())
```

A command receipt contains `receipt`, `event_seq`, `revision`, and `result`.
Use the returned project revision for the next mutation. Retry a lost response
with the identical request and key; changing any argument or expected revision
with that key is rejected. A conflict uses a new key and current revision.
Authentication and current authority are checked before replay. Failed commands
do not consume keys or append events. Keys are scoped by project, principal and
authority epoch. JSON object field order does not affect identity.

Replace `command` with `"query":{"kind":"snapshot","args":{}}` to inspect
state. `events` accepts `after` (exclusive global sequence cursor) and `limit`
(default100, maximum1000). Advance to the last event actually returned; gaps
are normal across projects/scopes. Queries return only the authenticated scope.
Own attempt observations and operation transitions derive event task identity
from their retained attempt/operation, so lifecycle changes reconnect correctly.

Commands and required arguments:

| Command | Arguments | Authority |
| --- | --- | --- |
| `create_project` | `name`, `base` | operator |
| `create_task` | `task`, `work_ref:{deployment,project,item}`, `source_revision`, `brief`; optional checked `brief_digest` | operator/lead |
| `admit` | `task` | operator/lead |
| `replace_lead` | `{}` | operator |
| `pause_dispatch` | `paused` boolean | operator/lead |
| `abort_task` | `task` | operator/lead |
| `cancel_attempt` | `attempt` | operator/lead |
| `observe_attempt` | `attempt`, `state`, `observation` | operator |
| `transition_operation` | `operation`, `state`, `observation` | operator |
| `ask_question` | `task`, `text` | operator/lead/own attempt |
| `answer_question` | `question`, `text` | operator/lead |
| `record_decision` | `text` | operator/lead |
| `send_message` | `recipient` principal, `text` | scoped principal |
| `ack_message` | `message` | recipient only |
| `report_progress` | `task`, `text` | operator/lead/own attempt |

Project base must be a full 40- or 64-hex Git commit OID, checked again at admission.
Symbolic refs, abbreviations and malformed IDs are refused atomically. Object
existence/retention belongs to ticket04.

`admit` returns the attempt, slot, prepared start operation, pinned base/brief,
and attempt principal/token/epoch. `replace_lead` returns a fresh lead grant;
old lead grants fail immediately, while attempt authority stays independent.
Token-bearing receipts stay private to their authenticated issuer.
`dispatch_context` query (`attempt`) is operator-only and retrieves the retained
current unpaused attempt grant for the controller-owned adapter. `pending_operations`
and `storage_configuration` queries are operator-only. Snapshots and events never
expose grant tokens; attempts see their own tasks, questions, operations and
sent/received messages. Message and acknowledgement events use retained sender/
recipient identities, including acknowledgement replay to the original sender;
caller task metadata never widens a message audience. Decisions are shared within the project.

There are two slots across the entire controller. WorkRef is canonical per project, so aliases cannot double-admit the same work item.
Admission pins immutable brief
and source revision/digest and journals a start before acknowledgement. Dispatch
uses the supervised runtime described below. `prepared`, `applying`, and `unknown` operations survive
restart for reconciliation; restart does not blindly dispatch or release slots.
Cancellation records its own prepared operation, revokes the attempt grant, and
retains capacity. Task abortion changes only task outcome. Only privileged
`observe_attempt(state="exited")` releases a slot in the storage-only library
fixture. The socket service refuses externally supplied terminal observations
and operation transitions; runtime mode refuses all external attempt observations.
Only the controller-owned adapter translates validated supervisor evidence into
these storage mutations. `Controller::handle` without the runtime remains an
unqualified storage fixture, unsuitable as a product lifecycle endpoint.

The supported operation transitions are prepared → applying/failed/unknown,
applying → confirmed/failed/unknown, unknown → applying/confirmed/failed.
Confirmed/failed are terminal. Observed attempts may move to running, unknown,
or exited; exited is terminal. No operation outcome implies an attempt exited.
Runtime effects must happen between separate journal commands, outside SQLite
transactions. Future adapters must reconcile ambiguous starts before retrying.

Version1 is a fresh-project migration applied atomically; unknown schema versions
fail closed. Candidates, verification and acceptance have separate immutable
schema records reserved for ticket04. No candidate/acceptance/landing command,
artifact publication, backup/restore procedure or Kata adapter exists yet.
Do not copy a live DB without its WAL, overwrite it with an older backup,
or infer power-loss durability from process-kill tests. A supported restore path
must add explicit authority rotation and external-effect reconciliation.

The ticket02 runtime requires Linux with process pidfds, `/usr/bin/bwrap` with unprivileged namespace
support, and the standard `/usr` toolchain. Configure a dedicated supervisor
outside controller and terminal lifetimes. Its root, socket, secret and controller
storage must stay outside the `/usr` toolchain mount and worker mounts. Retain the
supervisor root on supported local persistent storage alongside the SQLite
authority; never delete or restore its execution records independently.

For example, create a private configuration with an operator-selected executable
and literal argument vector (no shell expansion):

```json
{"root":"/tmp/corenius-runtime/executions","profile":{"executable":"/usr/bin/sleep","args":["120"]}}
```

The root directory must already exist, use its canonical absolute path, and be
dedicated to this controller deployment. Set distinct retained secrets
`CORENIUS_OPERATOR_TOKEN` and `CORENIUS_SUPERVISOR_TOKEN` through your secret
handling. Start these as separate services:

```sh
./target/debug/corenius-attempt-supervisor /tmp/corenius-runtime/supervisor.json /tmp/corenius-runtime/supervisor.sock
CORENIUS_SUPERVISOR_SOCKET=/tmp/corenius-runtime/supervisor.sock \
  ./target/debug/corenius-sqlite-controller /tmp/corenius-private/state.db /tmp/corenius-private/api.sock
```

The configured daemon automatically drains and reconciles all projects on startup
and every 250ms between bounded service requests. Normal clients issue admission
and cancellation through the team API; the lead and outer observers never
dispatch through the supervisor. This operator-only request additionally allows
an explicit reconciliation step for diagnosis:

```json
{"auth":{"principal":"operator","token":"YOUR_RETAINED_OPERATOR_SECRET"},"project":"demo","runtime":{"kind":"reconcile"}}
```

The daemon observes exits and cancellation completion automatically. Admission
and cancellation receipts record durable intent before any process effects.
Cancellation revokes worker authority immediately and keeps the slot until
identity-bound termination or a durable never-started tombstone is observed.
Pausing dispatch suppresses pending starts while permitting observation and
cancellation. Reconciliation accepts no caller-selected identity, lifecycle
state, principal, executable, profile or host path. The adapter uses short journal
transactions separated from all supervisor transport and process effects.

One serialized supervisor owns each operation-keyed effect. It persists a random
execution handle, original supervisor incarnation and kernel boot ID before
dispatch. Live records additionally retain monitor PID/start ticks and actual
namespace-init PID/start ticks/PID namespace inode, validated through the kernel.
The supervisor opens a provisional kernel pidfd, validates its process target,
namespace PID1 identity, start identity and parent relationship to the owned
monitor, then confirms process liveness before retaining it as cancellation
authority. Qualification failures drop the provisional descriptor without
signalling it.
The adjacent installed `corenius-attempt-gate` binary is mounted read-only and
blocks workload exec on a private stdin gate until identity is validated and
durably recorded, then restores null stdin before exec. Short-lived profiles
cannot race identity sampling. Setup errors terminate owned children and retain
unknown capacity when whole-process termination cannot be established.
The controller retains and checks that immutable identity on adoption. Lost start
replies are resolved through the original operation ID before dispatch; an
acknowledged execution missing from the supervisor is unknown and is never
restarted. The supervisor's lifetime lock and durable cancellation tombstones
prevent duplicate starts and late-start cancellation races.

Each execution runs in Insula's bubblewrap boundary with private workspace, home
and scratch, cleared environment, isolated PID/network namespaces, a private
`/proc`, and read-only `/usr`. Host home, controller database/socket, supervisor
records/socket, SSH agent, canonical Git metadata, credentials and other attempts
are absent. The worker is namespace PID1, so Linux terminates its descendants
when its whole process exits, including descendants that create new sessions. Cancellation
signals the retained namespace-init pidfd and terminates the owned monitor;
capacity release requires process-level pidfd readiness. A zombie leader with
live threads is still running for this proof, and parent-death signalling is not
an authority substitute. Logs remain in the private attempt
root, outside worker writable mounts. Roots and preparer-returned mount paths
refuse aliases and symlinks. `WorkspacePreparer`/`serve_with_workspace` expose a
trusted controller/operator hook receiving the pinned base and brief identity
for ticket04's private Git backend; the default creates empty fixture workspaces.

Supervisor restart deliberately leaves all retained nonterminal effects unknown:
it cannot reconstruct `Child` ownership from a PID. Controller restart with the
original supervisor alive adopts the same handles. Supervisor unavailability,
ambiguous setup or identity mismatch retain occupied slots; there is no unsafe
operator text override or automatic cleanup/recovery from supervisor loss.
Services are trusted local processes; workers cannot reach their private sockets
or secrets. Raw supervisor protocol access is a controller-owned internal seam.

Current profiles have null stdin and retained stdout/stderr; they provide no PTY,
model/provider connectivity, attempt tool gateway or live-runtime qualification.
The `/usr` base is a read-only host toolchain, not a hermetic dependency image.
Private Git workspaces, gateways, PTY attachment, artifact publication and the
dedicated live Codex trial remain later tickets. Terminal sessions may observe
these executions, but must not become their owner.

Run the reproducible standalone gate (real bwrap tests fail if namespaces are
unavailable, rather than silently skipping isolation):

```sh
sh tools/agents/checks.d/70-sqlite-controller.sh
cargo fmt --manifest-path crates/sqlite-controller/Cargo.toml --check
cargo clippy --manifest-path crates/sqlite-controller/Cargo.toml --locked --offline --all-targets --features fault-injection -- -D warnings
```
