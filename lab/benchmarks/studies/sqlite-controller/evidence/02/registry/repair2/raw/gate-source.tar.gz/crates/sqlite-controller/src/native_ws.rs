//! Bounded authenticated native WebSocket transport over a fixed qualified Unix bridge.
use base64::{Engine, engine::general_purpose::STANDARD};
use serde_json::{Value, json};
use sha1::{Digest, Sha1};
use std::{
    io::{Read, Write},
    os::unix::net::UnixStream,
    path::Path,
    time::{Duration, Instant},
};
use uuid::Uuid;
#[cfg(test)]
const RPC_TIMEOUT: Duration = Duration::from_millis(20);
#[cfg(not(test))]
const RPC_TIMEOUT: Duration = Duration::from_secs(8);
fn read_until(stream: &mut UnixStream, bytes: &mut [u8], deadline: Instant) -> Result<(), String> {
    let mut offset = 0;
    while offset < bytes.len() {
        let remaining = deadline
            .checked_duration_since(Instant::now())
            .filter(|d| !d.is_zero())
            .ok_or("native RPC deadline; acknowledgement unknown")?;
        stream
            .set_read_timeout(Some(remaining))
            .map_err(|e| e.to_string())?;
        match stream.read(&mut bytes[offset..]) {
            Ok(0) => return Err("native connection closed".into()),
            Ok(n) => offset += n,
            Err(e) if matches!(e.kind(), std::io::ErrorKind::Interrupted) => continue,
            Err(e) => return Err(e.to_string()),
        }
    }
    Ok(())
}
fn write_until(stream: &mut UnixStream, bytes: &[u8], deadline: Instant) -> Result<(), String> {
    let mut offset = 0;
    while offset < bytes.len() {
        let remaining = deadline
            .checked_duration_since(Instant::now())
            .filter(|d| !d.is_zero())
            .ok_or("native write deadline; acknowledgement unknown")?;
        stream
            .set_write_timeout(Some(remaining))
            .map_err(|e| e.to_string())?;
        match stream.write(&bytes[offset..]) {
            Ok(0) => return Err("native connection closed".into()),
            Ok(n) => offset += n,
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e.to_string()),
        }
    }
    Ok(())
}
fn event_thread(event: &Value) -> Option<&str> {
    event["params"]["threadId"]
        .as_str()
        .or_else(|| event["params"]["thread"]["id"].as_str())
}
pub struct NativeWs {
    stream: UnixStream,
    sequence: u64,
    pending: Vec<Value>,
    threads: std::collections::HashSet<String>,
    pub identity: String,
}
impl NativeWs {
    pub fn connect(path: &Path, token: &str, start: &str) -> Result<Self, String> {
        Self::connect_with_timeout(path, token, start, RPC_TIMEOUT)
    }
    pub fn require_ready(path: &Path, token: &str, start: &str) -> Result<(), String> {
        Self::connect_with_timeout(path, token, start, Duration::from_millis(200)).map(|_| ())
    }
    fn connect_with_timeout(
        path: &Path,
        token: &str,
        start: &str,
        timeout: Duration,
    ) -> Result<Self, String> {
        if start.parse::<u64>().is_err() || token.contains(['\r', '\n']) {
            return Err("native connection identity refused".into());
        }
        let mut stream = UnixStream::connect(path).map_err(|e| e.to_string())?;
        stream
            .set_read_timeout(Some(timeout))
            .map_err(|e| e.to_string())?;
        stream
            .set_write_timeout(Some(timeout))
            .map_err(|e| e.to_string())?;
        let key = STANDARD.encode(Uuid::new_v4().as_bytes());
        write!(stream,"GET /?corenius_start={start} HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: {key}\r\nAuthorization: Bearer {token}\r\n\r\n").map_err(|e|e.to_string())?;
        let upgrade_deadline = Instant::now() + timeout;
        let mut header = Vec::new();
        let mut byte = [0];
        while !header.ends_with(b"\r\n\r\n") {
            if header.len() > 16384 {
                return Err("native upgrade bound".into());
            }
            read_until(&mut stream, &mut byte, upgrade_deadline)?;
            header.push(byte[0]);
        }
        let header = String::from_utf8(header).map_err(|e| e.to_string())?;
        let accept = STANDARD.encode(Sha1::digest(format!(
            "{key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        )));
        if !header.starts_with("HTTP/1.1 101 ")
            || !header.lines().any(|l| {
                l.split_once(':').is_some_and(|(k, v)| {
                    k.eq_ignore_ascii_case("sec-websocket-accept") && v.trim() == accept
                })
            })
        {
            return Err("native websocket upgrade refused".into());
        }
        Ok(Self {
            stream,
            sequence: 0,
            pending: Vec::new(),
            threads: std::collections::HashSet::new(),
            identity: Uuid::new_v4().to_string(),
        })
    }
    pub fn retain_threads(
        &mut self,
        threads: std::collections::HashSet<String>,
    ) -> Result<(), String> {
        if threads.len() > 1024 {
            return Err("native active thread identity bound".into());
        }
        self.pending
            .retain(|event| event_thread(event).is_some_and(|id| threads.contains(id)));
        self.threads = threads;
        Ok(())
    }
    pub fn allow_thread(&mut self, thread: &str) -> Result<(), String> {
        if !self.threads.contains(thread) && self.threads.len() >= 1024 {
            return Err("native active thread identity bound".into());
        }
        self.threads.insert(thread.into());
        Ok(())
    }
    fn send(&mut self, opcode: u8, bytes: &[u8], deadline: Instant) -> Result<(), String> {
        let mask = *Uuid::new_v4().as_bytes();
        let mut frame = vec![0x80 | opcode];
        if bytes.len() < 126 {
            frame.push(0x80 | bytes.len() as u8)
        } else if bytes.len() <= 65535 {
            frame.push(0xfe);
            frame.extend_from_slice(&(bytes.len() as u16).to_be_bytes())
        } else {
            frame.push(0xff);
            frame.extend_from_slice(&(bytes.len() as u64).to_be_bytes())
        }
        frame.extend_from_slice(&mask[..4]);
        frame.extend(bytes.iter().enumerate().map(|(i, b)| b ^ mask[i % 4]));
        write_until(&mut self.stream, &frame, deadline)
    }
    fn receive(&mut self, deadline: Instant) -> Result<Value, String> {
        let mut body = Vec::new();
        let mut started = false;
        loop {
            let mut header = [0; 2];
            read_until(&mut self.stream, &mut header, deadline)?;
            if header[0] & 0x70 != 0 || header[1] & 0x80 != 0 {
                return Err("native frame flags refused".into());
            }
            let opcode = header[0] & 15;
            let mut len = (header[1] & 127) as u64;
            if len == 126 {
                let mut b = [0; 2];
                read_until(&mut self.stream, &mut b, deadline)?;
                len = u16::from_be_bytes(b) as u64
            } else if len == 127 {
                let mut b = [0; 8];
                read_until(&mut self.stream, &mut b, deadline)?;
                len = u64::from_be_bytes(b)
            }
            if len > 4 * 1024 * 1024 || body.len() + len as usize > 4 * 1024 * 1024 {
                return Err("native frame bound".into());
            }
            let mut payload = vec![0; len as usize];
            read_until(&mut self.stream, &mut payload, deadline)?;
            match opcode {
                8 => return Err("native connection closed".into()),
                9 => {
                    self.send(10, &payload, deadline)?;
                    continue;
                }
                10 => continue,
                1 if !started => started = true,
                0 if started => {}
                _ => return Err("native opcode refused".into()),
            }
            body.extend(payload);
            if header[0] & 0x80 != 0 {
                return serde_json::from_slice(&body).map_err(|e| e.to_string());
            }
        }
    }
    pub fn rpc(&mut self, method: &str, params: Value) -> Result<Value, String> {
        self.rpc_before(method, params, Instant::now() + RPC_TIMEOUT)
    }
    pub fn thread_is_loaded(&mut self, thread: &str) -> Result<bool, String> {
        let deadline = Instant::now() + RPC_TIMEOUT;
        let mut cursor = Value::Null;
        let mut seen = std::collections::HashSet::new();
        let mut count = 0;
        loop {
            let page = self.rpc_before(
                "thread/loaded/list",
                json!({"limit":100,"cursor":cursor}),
                deadline,
            )?;
            let ids = page["data"]
                .as_array()
                .ok_or("native loaded page data missing")?;
            if ids.iter().any(|id| id.as_str().is_none_or(str::is_empty)) {
                return Err("native loaded page identity malformed".into());
            }
            count += ids.len();
            if count > 10_000 || seen.len() >= 100 {
                return Err("native loaded pagination resource bound; presence unknown".into());
            }
            let next = match page.get("nextCursor") {
                None | Some(Value::Null) => None,
                Some(Value::String(value)) if !value.is_empty() && value.len() <= 4096 => {
                    Some(value.clone())
                }
                _ => return Err("native loaded cursor malformed".into()),
            };
            if let Some(next) = &next
                && !seen.insert(next.clone())
            {
                return Err("native loaded cursor repeated".into());
            }
            if ids.iter().any(|id| id == thread) {
                return Ok(true);
            }
            match next {
                None => return Ok(false),
                Some(next) => cursor = json!(next),
            }
        }
    }
    fn rpc_before(
        &mut self,
        method: &str,
        params: Value,
        deadline: Instant,
    ) -> Result<Value, String> {
        self.sequence += 1;
        let id = format!("controller-{}", self.sequence);
        self.send(
            1,
            &serde_json::to_vec(&json!({"id":id,"method":method,"params":params}))
                .map_err(|e| e.to_string())?,
            deadline,
        )?;
        let mut starting = std::collections::HashSet::new();
        loop {
            if Instant::now() > deadline {
                return Err("native RPC deadline; acknowledgement unknown".into());
            }
            let value = self.receive(deadline)?;
            if value.get("method").is_none() && value["id"] == id {
                if let Some(error) = value.get("error") {
                    return Err(format!("native RPC refused: {error}"));
                }
                let result = value
                    .get("result")
                    .cloned()
                    .ok_or("native reply result missing")?;
                if method == "thread/start" {
                    let thread = result["thread"]["id"]
                        .as_str()
                        .filter(|id| !id.is_empty())
                        .ok_or("native created thread identity missing")?;
                    self.allow_thread(thread)?;
                    self.retain_threads(self.threads.clone())?;
                }
                return Ok(result);
            }
            #[cfg(feature = "fault-injection")]
            if value["method"] == "thread/name/updated"
                && let Ok(path) = std::env::var("CORENIUS_TEST_RETIRED_EVENTS")
            {
                use std::fs::OpenOptions;
                let mut file = OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(format!("{path}.received"))
                    .map_err(|e| e.to_string())?;
                writeln!(file, "{value}").map_err(|e| e.to_string())?;
            }
            if method == "thread/start"
                && value["method"] == "thread/started"
                && let Some(thread) = event_thread(&value)
            {
                starting.insert(thread.to_owned());
            }
            if !event_thread(&value)
                .is_some_and(|thread| self.threads.contains(thread) || starting.contains(thread))
            {
                continue;
            }
            self.pending.push(value);
            if self.pending.len() > 1024 {
                return Err("native event buffer bound".into());
            }
        }
    }
    pub fn notify(&mut self, method: &str, params: Value) -> Result<(), String> {
        self.send(
            1,
            &serde_json::to_vec(&json!({"method":method,"params":params}))
                .map_err(|e| e.to_string())?,
            Instant::now() + RPC_TIMEOUT,
        )
    }
    #[cfg(feature = "fault-injection")]
    pub fn buffered_events(&self) -> &[Value] {
        &self.pending
    }
    pub fn take_events_for(&mut self, thread: &str) -> Vec<Value> {
        let mut selected = Vec::new();
        self.pending.retain(|event| {
            let identity = event["params"]["threadId"]
                .as_str()
                .or_else(|| event["params"]["thread"]["id"].as_str());
            match identity {
                Some(identity) if identity == thread => {
                    selected.push(event.clone());
                    false
                }
                Some(_) => true,
                None => false,
            }
        });
        selected
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    // Declared transport fixtures, not native protocol qualification: malformed
    // wire data must fail closed and an exhausted valid scan must report absence.
    fn scan_pages(pages: Vec<Value>) -> Result<bool, String> {
        let (stream, mut peer) = UnixStream::pair().unwrap();
        let producer = std::thread::spawn(move || {
            for (index, page) in pages.into_iter().enumerate() {
                let mut header = [0; 2];
                peer.read_exact(&mut header).unwrap();
                let mut len = (header[1] & 127) as usize;
                if len == 126 {
                    let mut b = [0; 2];
                    peer.read_exact(&mut b).unwrap();
                    len = u16::from_be_bytes(b) as usize;
                }
                let mut mask = [0; 4];
                peer.read_exact(&mut mask).unwrap();
                let mut request = vec![0; len];
                peer.read_exact(&mut request).unwrap();
                for (i, byte) in request.iter_mut().enumerate() {
                    *byte ^= mask[i % 4];
                }
                let request: Value = serde_json::from_slice(&request).unwrap();
                assert_eq!(request["method"], "thread/loaded/list");
                let body = serde_json::to_vec(
                    &json!({"id":format!("controller-{}",index+1),"result":page}),
                )
                .unwrap();
                let mut frame = vec![0x81];
                if body.len() < 126 {
                    frame.push(body.len() as u8);
                } else {
                    frame.push(126);
                    frame.extend_from_slice(&(body.len() as u16).to_be_bytes());
                }
                frame.extend(body);
                peer.write_all(&frame).unwrap();
            }
        });
        let mut ws = NativeWs {
            stream,
            sequence: 0,
            pending: Vec::new(),
            threads: std::collections::HashSet::new(),
            identity: "owned-wire-pagination".into(),
        };
        let result = ws.thread_is_loaded("absent");
        drop(ws);
        producer.join().unwrap();
        result
    }
    #[test]
    fn loaded_scan_exhaustion_reports_absent_identity() {
        assert!(
            !scan_pages(vec![
                json!({"data":["a"],"nextCursor":"next"}),
                json!({"data":["b"],"nextCursor":null})
            ])
            .unwrap()
        );
    }
    #[test]
    fn loaded_scan_repeated_cursor_fails_closed() {
        assert!(
            scan_pages(vec![
                json!({"data":[],"nextCursor":"loop"}),
                json!({"data":[],"nextCursor":"loop"})
            ])
            .unwrap_err()
            .contains("cursor repeated")
        );
    }
    #[test]
    fn loaded_scan_malformed_cursor_fails_closed() {
        assert!(
            scan_pages(vec![json!({"data":[],"nextCursor":42})])
                .unwrap_err()
                .contains("cursor malformed")
        );
    }
    #[test]
    fn partial_native_frame_cannot_extend_absolute_rpc_deadline() {
        let (stream, mut peer) = UnixStream::pair().unwrap();
        stream.set_read_timeout(Some(RPC_TIMEOUT)).unwrap();
        let producer = std::thread::spawn(move || {
            let payload = b"{\"id\":\"controller-1\",\"result\":{}}";
            peer.write_all(&[0x81, payload.len() as u8]).unwrap();
            for byte in payload {
                std::thread::sleep(Duration::from_millis(3));
                if peer.write_all(&[*byte]).is_err() {
                    break;
                }
            }
        });
        let mut ws = NativeWs {
            stream,
            sequence: 0,
            pending: Vec::new(),
            threads: std::collections::HashSet::new(),
            identity: "owned-wire-fixture".into(),
        };
        let started = Instant::now();
        let result = ws.rpc("thread/read", json!({}));
        assert!(
            result.is_err(),
            "partial frame must not outlive absolute native RPC deadline: {result:?}"
        );
        assert!(started.elapsed() < Duration::from_millis(80));
        drop(ws);
        producer.join().unwrap();
    }
}
