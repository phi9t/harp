import importlib.util,pathlib,sys,os
root=pathlib.Path('/workspace');mode=sys.argv[1];host=sys.argv[2]
assert not pathlib.Path(host).exists(), 'verifier must not see controller root'
assert not pathlib.Path('/root/.ssh').exists()
assert 'CapEff:\t0000000000000000' in pathlib.Path('/proc/self/status').read_text()
for name in (['a','b'] if mode=='combined' else [mode]):
 spec=importlib.util.spec_from_file_location('task_'+name,root/('task_'+name+'.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 assert module.answer()==('A' if name=='a' else 'B'), 'fixed admitted task contract failed'
print('FIXED_CONTRACT_PASS',mode,'VERIFIER_OS_ISOLATED')
