use corenius_sqlite_controller::Controller;
use serde_json::json;
#[test]
fn workspace_inventory_is_an_authenticated_controller_projection() {
    let r = tempfile::tempdir().unwrap();
    let c = Controller::open(r.path().join("state.db"), "operator-git-secret").unwrap();
    let response=c.handle(json!({"auth":{"principal":"operator","token":"operator-git-secret"},"project":"p","query":{"kind":"workspace_inventory","args":{}}}));
    assert!(
        response.is_ok(),
        "workspace inventory must be a supported authenticated projection: {response:?}"
    );
}
#[test]
#[cfg(feature = "fault-injection")]
fn actual_private_git_candidates_verification_landing_recovery_and_hygiene() {
    let output = std::process::Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/git_protocol.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}
