use super::*;
use rusqlite::types::ValueRef;

pub(super) fn rows(c: &Connection, sql: &str, values: &[&dyn rusqlite::ToSql]) -> Result<Value> {
    let mut stmt = db(c.prepare(sql))?;
    let names: Vec<String> = stmt.column_names().into_iter().map(str::to_owned).collect();
    let mapped = db(stmt.query_map(values, |row| {
        let mut object = serde_json::Map::new();
        for (i, name) in names.iter().enumerate() {
            let v = match row.get_ref(i)? {
                ValueRef::Null => Value::Null,
                ValueRef::Integer(n)
                    if matches!(
                        name.as_str(),
                        "acknowledged" | "cancel_requested" | "paused"
                    ) =>
                {
                    json!(n != 0)
                }
                ValueRef::Integer(n) => json!(n),
                ValueRef::Real(n) => json!(n),
                ValueRef::Text(s) => json!(String::from_utf8_lossy(s)),
                ValueRef::Blob(_) => Value::Null,
            };
            object.insert(name.clone(), v);
        }
        Ok(Value::Object(object))
    }))?;
    let values: Vec<Value> = db(mapped.collect())?;
    Ok(Value::Array(values))
}

pub(super) fn run(c: &Connection, p: &Principal, project: &str, q: Query) -> Result<Value> {
    match q.kind.as_str() {
        "participant_context" => kata::context(c, p, project),
        "codex_registry" => {
            if p.role != "operator" {
                return Err("authorization: operator required".into());
            }
            let version: i64 = db(c.pragma_query_value(None, "user_version", |r| r.get(0)))?;
            if version == 1 {
                return Ok(json!({"configured":false,"servers":[],"bindings":[],"operations":[]}));
            }
            let mut servers = rows(
                c,
                "SELECT id,document,state FROM codex_servers ORDER BY rowid",
                &[],
            )?;
            let mut bindings = rows(
                c,
                "SELECT id,role,attempt,authority_epoch,document,state FROM codex_bindings WHERE project=?1 ORDER BY rowid",
                &[&project],
            )?;
            let mut operations = rows(
                c,
                "SELECT id,binding,kind,state,intent,observation FROM codex_operations WHERE project=?1 ORDER BY rowid",
                &[&project],
            )?;
            for collection in [&mut servers, &mut bindings, &mut operations] {
                for item in collection.as_array_mut().unwrap() {
                    for field in ["document", "intent", "observation"] {
                        if let Some(raw) = item[field].as_str() {
                            item[field] = serde_json::from_str(raw).map_err(|e| e.to_string())?;
                        }
                    }
                }
            }
            Ok(
                json!({"configured":true,"servers":servers,"bindings":bindings,"operations":operations}),
            )
        }
        "runtime_projects" => {
            if p.role != "operator" {
                return Err("authorization: operator required".into());
            }
            rows(c, "SELECT id FROM projects ORDER BY rowid", &[])
        }
        "storage_configuration" => {
            if p.role != "operator" {
                return Err("authorization: operator required".into());
            }
            Ok(
                json!({"journal_mode":db(c.pragma_query_value(None,"journal_mode",|r|r.get::<_,String>(0)))?,
                "synchronous":db(c.pragma_query_value(None,"synchronous",|r|r.get::<_,i64>(0)))?,
                "foreign_keys":db(c.pragma_query_value(None,"foreign_keys",|r|r.get::<_,i64>(0)))?,
                "schema_version":db(c.pragma_query_value(None,"user_version",|r|r.get::<_,i64>(0)))?}),
            )
        }
        "events" => {
            let after = i64::try_from(q.args.get("after").and_then(Value::as_u64).unwrap_or(0))
                .map_err(|_| "event cursor out of range")?;
            let limit = q
                .args
                .get("limit")
                .and_then(Value::as_u64)
                .unwrap_or(100)
                .clamp(1, 1000) as i64;
            let task = p.task.as_deref();
            let mut events = rows(
                c,
                "SELECT e.seq,e.task,e.kind,e.body FROM events e WHERE e.project=?1 AND e.seq>?2 AND (
                    ?3 IS NULL OR
                    (e.kind IN ('send_message','ack_message') AND EXISTS (
                        SELECT 1 FROM messages m WHERE m.project=e.project
                        AND m.id=json_extract(e.body,'$.result.message') AND (?4=m.sender OR ?4=m.recipient))) OR
                    (e.kind NOT IN ('send_message','ack_message') AND
                        (e.task=?3 OR e.audience=?4 OR e.kind IN ('record_decision','pause_dispatch')))
                ) ORDER BY e.seq LIMIT ?5",
                &[&project, &after, &task, &p.id, &limit],
            )?;
            for event in events.as_array_mut().unwrap() {
                let raw = event["body"].as_str().unwrap();
                event["body"] = serde_json::from_str(raw).map_err(|e| e.to_string())?;
            }
            Ok(events)
        }
        "dispatch_context" => {
            if p.role != "operator" {
                return Err("authorization: operator required".into());
            }
            let attempt = text(&q.args, "attempt")?;
            let paused: bool = db(c.query_row(
                "SELECT paused FROM projects WHERE id=?1",
                [project],
                |r| r.get(0),
            ))?;
            if paused {
                return Err("dispatch paused".into());
            }
            let (epoch,state,cancel):(i64,String,bool)=db(c.query_row("SELECT scope_epoch,state,cancel_requested FROM attempts WHERE project=?1 AND id=?2",params![project,attempt],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?))))?;
            if state == "exited" || cancel {
                return Err("dispatch grant revoked".into());
            }
            let receipts = rows(
                c,
                "SELECT response FROM receipts WHERE project=?1 ORDER BY rowid",
                &[&project],
            )?;
            for receipt in receipts.as_array().unwrap() {
                let response: Value = serde_json::from_str(receipt["response"].as_str().unwrap())
                    .map_err(|e| e.to_string())?;
                let grant = &response["result"];
                if grant["attempt"].as_str() == Some(attempt)
                    && grant["scope_epoch"].as_i64() == Some(epoch)
                    && grant["token"].is_string()
                {
                    return Ok(grant.clone());
                }
            }
            Err("retained dispatch grant missing".into())
        }
        "pending_operations" => {
            if p.role != "operator" {
                return Err("authorization: operator required".into());
            }
            rows(
                c,
                "SELECT id,attempt,kind,state,payload,observation FROM operations WHERE project=?1 AND state IN ('prepared','applying','unknown') ORDER BY rowid",
                &[&project],
            )
        }
        "snapshot" => {
            let mut project_row = rows(
                c,
                "SELECT id,base,revision,lead_epoch,paused FROM projects WHERE id=?1",
                &[&project],
            )?;
            let project_row = project_row
                .as_array_mut()
                .unwrap()
                .pop()
                .ok_or("project missing")?;
            let task = p.task.as_deref();
            let attempt = p.attempt.as_deref();
            let tasks = rows(
                c,
                "SELECT t.id,t.state,b.id AS brief,b.work_ref,b.source_revision,b.body,b.digest FROM tasks t JOIN briefs b ON t.brief=b.id WHERE t.project=?1 AND (?2 IS NULL OR t.id=?2) ORDER BY t.rowid",
                &[&project, &task],
            )?;
            let attempts = rows(
                c,
                "SELECT id,task,brief,base,state,scope_epoch,cancel_requested,observation FROM attempts WHERE project=?1 AND (?2 IS NULL OR id=?2) ORDER BY rowid",
                &[&project, &attempt],
            )?;
            let operations = rows(
                c,
                "SELECT id,attempt,kind,state,payload,observation FROM operations WHERE project=?1 AND (?2 IS NULL OR attempt=?2) ORDER BY rowid",
                &[&project, &attempt],
            )?;
            let questions = rows(
                c,
                "SELECT id,task,sender,text,answer,answered_by FROM questions WHERE project=?1 AND (?2 IS NULL OR task=?2) ORDER BY rowid",
                &[&project, &task],
            )?;
            let worker = (p.role == "attempt").then_some(p.id.as_str());
            let messages = rows(
                c,
                "SELECT id,sender,recipient,text,acknowledged FROM messages WHERE project=?1 AND (?2 IS NULL OR sender=?2 OR recipient=?2) ORDER BY rowid",
                &[&project, &worker],
            )?;
            let decisions = rows(
                c,
                "SELECT id,author,text FROM decisions WHERE project=?1 ORDER BY rowid",
                &[&project],
            )?;
            let occupied: i64 = db(c.query_row(
                "SELECT COUNT(*) FROM slots WHERE attempt IS NOT NULL",
                [],
                |r| r.get(0),
            ))?;
            Ok(
                json!({"project":project_row,"revision":project_row["revision"],"occupied_slots":occupied,"tasks":tasks,"attempts":attempts,"operations":operations,"questions":questions,"messages":messages,"decisions":decisions}),
            )
        }
        _ => Err(format!("unknown query: {}", q.kind)),
    }
}
