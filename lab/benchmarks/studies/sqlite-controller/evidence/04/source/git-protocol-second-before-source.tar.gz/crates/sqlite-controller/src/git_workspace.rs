//! Private, complete Git repositories. Host Git only reads controller-owned stores;
//! worker metadata is inspected by fixed commands in a separate OS boundary.
use crate::{Result, commit_oid, hash, supervisor::{Binding, Workspace, WorkspacePreparer}};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{fs::{self, File, OpenOptions}, io::Write, os::unix::{fs::{MetadataExt, OpenOptionsExt, PermissionsExt}}, path::{Path, PathBuf}, process::{Command, Output}, time::{Duration, Instant}};

#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Tool { pub path: PathBuf, pub sha256: String }
#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Suite {
    pub id: String, pub task: String, pub base: Option<String>,
    pub script: Tool, pub args: Vec<String>,
}
#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Policy {
    pub project: String, pub root: PathBuf, pub attempts_root: PathBuf,
    pub canonical: PathBuf, pub protected_ref: String, pub git: Tool,
    pub python: Tool, pub bubblewrap: Tool, pub suites: Vec<Suite>,
}
#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Ownership { pub binding: Binding, pub workspace_identity: String, pub git_identity: String }
#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RepositoryState { pub commit: String, pub tree: String, pub refs: Vec<(String,String)>, pub status: String }
#[derive(Clone)]
pub struct GitBackend { pub policy: Policy, pub identity: String }

pub fn digest(bytes: &[u8]) -> String { format!("{:x}",Sha256::digest(bytes)) }
pub fn check_tool(tool: &Tool) -> Result<()> {
    if !tool.path.is_absolute() || digest(&fs::read(&tool.path).map_err(|e|e.to_string())?) != tool.sha256 {
        return Err("pinned executable/suite identity changed".into());
    }
    Ok(())
}
pub fn directory(path: &Path) -> Result<()> {
    if !path.is_absolute() || path.canonicalize().map_err(|e|e.to_string())? != path
        || !fs::symlink_metadata(path).map_err(|e|e.to_string())?.is_dir() {
        return Err("directory ownership alias refused".into());
    }
    Ok(())
}
pub fn identity(path: &Path) -> Result<String> {
    directory(path)?; let m=fs::metadata(path).map_err(|e|e.to_string())?;
    Ok(format!("{}:{}",m.dev(),m.ino()))
}
/// Publish once, sync bytes and directory, and verify any existing content.
pub fn retain(path: &Path, bytes: &[u8]) -> Result<()> {
    if path.exists() {
        if fs::symlink_metadata(path).map_err(|e|e.to_string())?.file_type().is_symlink()
            || fs::read(path).map_err(|e|e.to_string())? != bytes { return Err("immutable retained bytes differ".into()); }
        return Ok(());
    }
    let temporary=path.with_file_name(format!(".{}.tmp",uuid::Uuid::new_v4()));
    let mut f=OpenOptions::new().write(true).create_new(true).mode(0o600).custom_flags(libc::O_NOFOLLOW).open(&temporary).map_err(|e|e.to_string())?;
    f.write_all(bytes).and_then(|()|f.sync_all()).map_err(|e|e.to_string())?;
    fs::hard_link(&temporary,path).map_err(|e|e.to_string())?;
    fs::remove_file(temporary).map_err(|e|e.to_string())?;
    File::open(path.parent().ok_or("retained parent missing")?).and_then(|f|f.sync_all()).map_err(|e|e.to_string())
}
fn output(mut command: Command) -> Result<Output> {
    // The bwrap monitor is our Child. Its PID cannot be reused before wait; the
    // private PID1 dies with this monitor on timeout, including descendants.
    let output_dir=tempfile_path()?;
    let stdout=File::create(output_dir.join("stdout")).map_err(|e|e.to_string())?;
    let stderr=File::create(output_dir.join("stderr")).map_err(|e|e.to_string())?;
    command.stdout(stdout).stderr(stderr);
    let mut child=command.spawn().map_err(|e|e.to_string())?;
    let deadline=Instant::now()+Duration::from_secs(30);
    let status=loop {
        if let Some(status)=child.try_wait().map_err(|e|e.to_string())? {break status;}
        if Instant::now()>=deadline { child.kill().map_err(|e|e.to_string())?; child.wait().map_err(|e|e.to_string())?; return Err("owned Git/verifier process timeout; no passing proof".into()); }
        std::thread::sleep(Duration::from_millis(5));
    };
    let result=Output{status,stdout:fs::read(output_dir.join("stdout")).map_err(|e|e.to_string())?,stderr:fs::read(output_dir.join("stderr")).map_err(|e|e.to_string())?};
    fs::remove_dir_all(output_dir).map_err(|e|e.to_string())?;
    Ok(result)
}
fn tempfile_path() -> Result<PathBuf> {
    let path=std::env::temp_dir().join(format!("corenius-git-output-{}",uuid::Uuid::new_v4()));
    fs::create_dir(&path).map_err(|e|e.to_string())?;
    fs::set_permissions(&path,fs::Permissions::from_mode(0o700)).map_err(|e|e.to_string())?; Ok(path)
}
const FIXED_GIT: &[&str]=&["-c","core.hooksPath=/dev/null","-c","core.fsmonitor=false","-c","core.untrackedCache=false","-c","core.sshCommand=/bin/false","-c","protocol.allow=never","-c","protocol.file.allow=always","-c","core.askPass=/bin/false","-c","credential.helper=","-c","uploadpack.allowFilter=false","-c","init.templateDir="];
impl GitBackend {
    pub fn open(path: &Path) -> Result<Self> {
        let policy:Policy=serde_json::from_slice(&fs::read(path).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
        for t in [&policy.git,&policy.python,&policy.bubblewrap] {check_tool(t)?;}
        for s in &policy.suites {check_tool(&s.script)?; if s.id.is_empty() || s.task.is_empty() { return Err("verification policy selector missing".into()); } }
        for p in [&policy.root,&policy.attempts_root,&policy.canonical] {directory(p)?; if p.starts_with("/usr") {return Err("Git authority inside worker toolchain mount".into());}}
        if policy.root.starts_with(&policy.attempts_root) || policy.canonical.starts_with(&policy.attempts_root)
            || policy.attempts_root.starts_with(&policy.root) || policy.attempts_root.starts_with(&policy.canonical)
            || !policy.protected_ref.starts_with("refs/heads/") {return Err("Git authority/workspace topology refused".into());}
        let identity=hash(&serde_json::to_string(&policy).map_err(|e|e.to_string())?);
        let backend=Self{policy,identity};
        backend.git(&backend.policy.canonical,&["check-ref-format",&backend.policy.protected_ref])?;
        for name in ["objects","artifacts","materializations","captures"] {
            let p=backend.policy.root.join(name);
            if !p.exists() {fs::create_dir(&p).map_err(|e|e.to_string())?;}
            directory(&p)?;
        }
        let store=backend.store();
        if !store.exists() {backend.init(&store,true)?;}
        backend.head()?;
        Ok(backend)
    }
    pub fn store(&self) -> PathBuf {self.policy.root.join("objects/store.git")}
    /// Only call on newly-created materializations or trusted controller repositories.
    pub fn git(&self, repo: &Path, args: &[&str]) -> Result<String> {
        check_tool(&self.policy.git)?;
        let mut c=Command::new(&self.policy.git.path);
        c.env_clear().env("PATH","/usr/bin:/bin").env("GIT_CONFIG_NOSYSTEM","1").env("GIT_CONFIG_GLOBAL","/dev/null").env("GIT_NO_REPLACE_OBJECTS","1").env("GIT_TERMINAL_PROMPT","0").args(FIXED_GIT).arg("-C").arg(repo).args(args);
        let o=output(c)?;
        if !o.status.success(){return Err(format!("trusted Git failed: {}",String::from_utf8_lossy(&o.stderr)));}
        String::from_utf8(o.stdout).map(|s|s.trim_end().to_owned()).map_err(|e|e.to_string())
    }
    pub fn init(&self,path:&Path,bare:bool)->Result<()> {
        let format=self.git(&self.policy.canonical,&["rev-parse","--show-object-format"])?;
        let parent=path.parent().ok_or("repo parent missing")?;
        let mut args=vec!["init","--template=","--object-format",format.as_str()];
        if bare {args.push("--bare");} args.push(path.to_str().ok_or("repo path encoding")?);
        self.git(parent,&args)?; Ok(())
    }
    pub fn head(&self)->Result<String> {self.git(&self.policy.canonical,&["rev-parse","--verify",&format!("{}^{{commit}}",self.policy.protected_ref)])}
    pub fn suite<'a>(&'a self,task:&str,base:&str)->Result<&'a Suite> {
        let exact:Vec<_>=self.policy.suites.iter().filter(|s|s.task==task && s.base.as_deref()==Some(base)).collect();
        let fallback:Vec<_>=self.policy.suites.iter().filter(|s|s.task==task && s.base.is_none()).collect();
        let choices=if exact.is_empty(){fallback}else{exact};
        if choices.len()!=1 {return Err("fixed verification policy missing/ambiguous for admitted contract".into());}
        Ok(choices[0])
    }
    pub fn artifact(&self,bytes:&[u8])->Result<String> {
        let digest=digest(bytes); retain(&self.policy.root.join("artifacts").join(&digest),bytes)?; Ok(digest)
    }
    pub fn bytes(&self,digest_value:&str)->Result<Vec<u8>> {
        if digest_value.len()!=64 || !digest_value.bytes().all(|b|b.is_ascii_hexdigit()) {return Err("artifact identity invalid".into());}
        let path=self.policy.root.join("artifacts").join(digest_value);
        if fs::symlink_metadata(&path).map_err(|e|e.to_string())?.file_type().is_symlink(){return Err("artifact alias refused".into());}
        let bytes=fs::read(path).map_err(|e|e.to_string())?;
        if digest(&bytes)!=digest_value {return Err("retained artifact digest mismatch".into());} Ok(bytes)
    }
    pub fn owned(&self,binding:&Binding)->Result<(PathBuf,Ownership)> {
        if binding.project!=self.policy.project || uuid::Uuid::parse_str(&binding.attempt).is_err(){return Err("workspace ownership outside policy".into());}
        let root=self.policy.attempts_root.join(&binding.attempt); directory(&root)?;
        let owner:Ownership=serde_json::from_slice(&fs::read(root.join("workspace-owner.json")).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
        let repo=root.join("workspace");
        if owner.binding!=*binding || owner.workspace_identity!=identity(&repo)? || owner.git_identity!=identity(&repo.join(".git"))? {
            return Err("workspace ownership/filesystem drift refused".into());
        } Ok((repo,owner))
    }
    fn boundary(&self,repo:&Path,scratch:&Path)->Result<Command> {
        check_tool(&self.policy.bubblewrap)?;
        let mut c=Command::new(&self.policy.bubblewrap.path);
        c.env_clear().args(["--unshare-all","--new-session","--die-with-parent","--as-pid-1","--clearenv","--ro-bind","/usr","/usr","--symlink","usr/bin","/bin","--symlink","usr/lib","/lib","--symlink","usr/lib64","/lib64","--proc","/proc","--dev","/dev","--tmpfs","/tmp","--dir","/home","--dir","/home/worker","--setenv","HOME","/home/worker","--setenv","PATH","/usr/bin:/bin","--setenv","GIT_CONFIG_NOSYSTEM","1","--setenv","GIT_CONFIG_GLOBAL","/dev/null","--setenv","GIT_NO_REPLACE_OBJECTS","1","--setenv","GIT_TERMINAL_PROMPT","0"])
            .arg("--bind").arg(repo).arg("/workspace").arg("--bind").arg(scratch).arg("/scratch").args(["--chdir","/workspace"]);
        Ok(c)
    }
    /// Capture and inspect untrusted .git ONLY inside the OS boundary. Fixed argv,
    /// disabled hooks/fsmonitor/replacements, no worker upload-pack on the host.
    pub fn inspect(&self,repo:&Path,scratch:&Path,bundle:bool)->Result<RepositoryState> {
        let script=r#"import subprocess,json,os
fixed=['-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-c','core.sshCommand=/bin/false','-c','credential.helper=']
def git(*args):return subprocess.check_output(['/run/git']+fixed+['-C','/workspace']+list(args),text=True).rstrip('\n')
assert os.path.isdir('/workspace/.git') and not os.path.islink('/workspace/.git')
assert not os.path.exists('/workspace/.git/objects/info/alternates'),'alternate objects refused'
assert not os.path.exists('/workspace/.git/info/grafts'),'grafts refused'
commit=git('rev-parse','--verify','HEAD^{commit}');tree=git('rev-parse','--verify',commit+'^{tree}')
refs=[line.split(' ',1) for line in git('for-each-ref','--format=%(refname) %(objectname)').splitlines()]
status=git('status','--porcelain=v1','--untracked-files=all')
if os.environ.get('CAPTURE_BUNDLE')=='1':git('bundle','create','/scratch/candidate.bundle',commit,'--all')
print(json.dumps({'commit':commit,'tree':tree,'refs':refs,'status':status}))
"#;
        let mut c=self.boundary(repo,scratch)?;
        c.arg("--ro-bind").arg(&self.policy.git.path).arg("/run/git").args(["--setenv","CAPTURE_BUNDLE",if bundle{"1"}else{"0"}]);
        c.arg(&self.policy.python.path).args(["-c",script]);
        let result=output(c)?;
        if !result.status.success(){return Err(format!("isolated worker Git refused: {}",String::from_utf8_lossy(&result.stderr)));}
        serde_json::from_slice(&result.stdout).map_err(|e|format!("isolated Git metadata malformed: {e}"))
    }
    pub fn import(&self,bundle_digest:&str,commit:&str,tree:&str)->Result<()> {
        commit_oid(commit)?;commit_oid(tree)?;self.bytes(bundle_digest)?;
        let path=self.policy.root.join("artifacts").join(bundle_digest);
        self.git(&self.store(),&["bundle","verify",path.to_str().ok_or("bundle path encoding")?])?;
        self.git(&self.store(),&["fetch","--no-tags",path.to_str().ok_or("bundle path encoding")?,commit])?;
        let actual=self.git(&self.store(),&["rev-parse","--verify",&format!("{commit}^{{tree}}")])?;
        if actual!=tree{return Err("candidate commit/tree differs from retained bundle".into());}
        self.git(&self.store(),&["update-ref",&format!("refs/candidates/{commit}"),commit])?;Ok(())
    }
    pub fn materialize(&self,bundle:&str,commit:&str,tree:&str)->Result<PathBuf> {
        self.import(bundle,commit,tree)?;
        let root=self.policy.root.join("materializations").join(uuid::Uuid::new_v4().to_string());
        fs::create_dir(&root).map_err(|e|e.to_string())?;
        let repo=root.join("workspace");self.init(&repo,false)?;
        self.git(&repo,&["fetch","--no-tags",self.policy.root.join("artifacts").join(bundle).to_str().ok_or("path encoding")?,commit])?;
        self.git(&repo,&["checkout","--detach",commit])?;
        fs::create_dir(root.join("scratch")).map_err(|e|e.to_string())?;Ok(repo)
    }
    pub fn verify(&self,repo:&Path,suite:&Suite)->Result<(bool,Vec<u8>,String)> {
        check_tool(&suite.script)?;check_tool(&self.policy.python)?;
        let environment=digest(&serde_json::to_vec(&(&self.policy.python,&self.policy.bubblewrap,"unshare-all/no-controller-mounts/PATH=/usr/bin:/bin")).map_err(|e|e.to_string())?);
        let mut c=self.boundary(repo,&repo.parent().ok_or("materialization parent")?.join("scratch"))?;
        c.arg("--ro-bind").arg(&suite.script.path).arg("/run/verification.py").arg(&self.policy.python.path).arg("/run/verification.py").args(&suite.args);
        let o=output(c)?;
        let log=serde_json::to_vec(&serde_json::json!({"argv":[self.policy.python.path.to_string_lossy(),"/run/verification.py"],"args":suite.args,"exit":o.status.code(),"stdout":String::from_utf8_lossy(&o.stdout),"stderr":String::from_utf8_lossy(&o.stderr),"suite":suite,"environment":environment,"os_isolated":true})).map_err(|e|e.to_string())?;
        Ok((o.status.success(),log,environment))
    }
    pub fn compare(&self,base:&str,candidate:&str)->Result<String> {
        self.git(&self.store(),&["diff","--no-ext-diff","--no-textconv",base,candidate,"--"])
    }
    pub fn ancestor(&self,repo:&Path,base:&str,candidate:&str)->Result<bool> {
        match self.git(repo,&["merge-base","--is-ancestor",base,candidate]) {Ok(_)=>Ok(true),Err(e) if e.starts_with("trusted Git failed:")=>Ok(false),Err(e)=>Err(e)}
    }
    pub fn land(&self,commit:&str,expected:&str)->Result<()> {
        if !self.ancestor(&self.store(),expected,commit)?{return Err("candidate does not fast-forward expected base".into());}
        self.git(&self.policy.canonical,&["fetch","--no-tags",self.store().to_str().ok_or("store path encoding")?,commit])?;
        self.git(&self.policy.canonical,&["update-ref",&self.policy.protected_ref,commit,expected])?;Ok(())
    }
}
/// Used by the actual supervisor, including native Codex executor profiles.
pub struct TrustedWorkspacePreparer(pub GitBackend);
impl WorkspacePreparer for TrustedWorkspacePreparer {
    fn prepare(&self,root:&Path,binding:&Binding)->Result<Workspace> {
        let g=&self.0;
        if root!=g.policy.attempts_root || binding.project!=g.policy.project {return Err("trusted workspace policy/attempt root mismatch".into());}
        commit_oid(&binding.base)?;
        let workspace=crate::supervisor::prepare_workspace(root,&binding.attempt)?;
        let seed=root.join(format!("seed-{}.bundle",binding.operation));
        g.git(&g.policy.canonical,&["bundle","create",seed.to_str().ok_or("seed path encoding")?,"--all"])?;
        // The existing empty workspace is exclusively ours, before any process is started.
        g.init(&workspace.workspace,false)?;
        g.git(&workspace.workspace,&["fetch","--no-tags",seed.to_str().ok_or("seed path encoding")?,&binding.base])?;
        g.git(&workspace.workspace,&["update-ref","refs/heads/attempt",&binding.base])?;
        g.git(&workspace.workspace,&["symbolic-ref","HEAD","refs/heads/attempt"])?;
        g.git(&workspace.workspace,&["reset","--hard",&binding.base])?;
        let owner=Ownership{binding:binding.clone(),workspace_identity:identity(&workspace.workspace)?,git_identity:identity(&workspace.workspace.join(".git"))?};
        retain(&root.join(&binding.attempt).join("workspace-owner.json"),&serde_json::to_vec(&owner).map_err(|e|e.to_string())?)?;
        Ok(workspace)
    }
}
