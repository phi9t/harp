import pathlib,os
def answer():
 try: pathlib.Path('/tmp/g4-o8e3hccl/secret').write_text('FORBIDDEN')
 except (FileNotFoundError,PermissionError): print('CANDIDATE_OUTSIDE_EFFECT_DENIED')
 else: raise AssertionError('verifier outside authority exposed')
 return 'Z'
