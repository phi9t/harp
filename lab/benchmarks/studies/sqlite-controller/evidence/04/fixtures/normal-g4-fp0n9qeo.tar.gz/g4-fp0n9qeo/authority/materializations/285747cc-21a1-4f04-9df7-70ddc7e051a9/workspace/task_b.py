import pathlib,os
def answer():
 try: pathlib.Path('/tmp/g4-fp0n9qeo/secret').write_text('FORBIDDEN')
 except (FileNotFoundError,PermissionError): print('CANDIDATE_OUTSIDE_EFFECT_DENIED')
 else: raise AssertionError('verifier outside authority exposed')
 return 'B'
