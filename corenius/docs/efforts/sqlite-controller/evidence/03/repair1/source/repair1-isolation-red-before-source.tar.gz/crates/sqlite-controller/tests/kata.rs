use std::process::Command;

#[test]
fn pinned_kata_public_protocol() {
    let status = Command::new("python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/kata_protocol.py"
        ))
        .env(
            "CONTROLLER_BINARY",
            env!("CARGO_BIN_EXE_corenius-sqlite-controller"),
        )
        .status()
        .expect("run retained real Kata fixture");
    assert!(
        status.success(),
        "real Kata/public controller qualification failed"
    );
}
