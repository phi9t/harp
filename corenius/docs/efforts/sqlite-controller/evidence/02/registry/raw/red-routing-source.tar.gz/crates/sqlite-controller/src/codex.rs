//! Controller-owned Codex registry. Runtime effects occur after journal commits.
use crate::{Controller, db};
use serde::Deserialize;
use std::{
    fs,
    path::{Path, PathBuf},
};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    schema_migration: String,
    topology: String,
    transport_root: PathBuf,
    servers: Vec<serde_json::Value>,
}

pub struct CodexRuntime {
    config: Config,
}
impl CodexRuntime {
    pub fn open(path: &Path, controller: &Controller) -> Result<Self, String> {
        let config: Config = serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
        if config.schema_migration != "1-to-2"
            || !matches!(config.topology.as_str(), "shared" | "separate")
        {
            return Err("explicit Codex schema migration/topology required".into());
        }
        if !config.transport_root.is_absolute() || config.transport_root.starts_with("/usr") {
            return Err("private native transport root required".into());
        }
        fs::create_dir_all(&config.transport_root).map_err(|e| e.to_string())?;
        if config
            .transport_root
            .canonicalize()
            .map_err(|e| e.to_string())?
            != config.transport_root
        {
            return Err("native transport aliases refused".into());
        }
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&config.transport_root, fs::Permissions::from_mode(0o700))
            .map_err(|e| e.to_string())?;
        let mut connection = controller
            .connection
            .lock()
            .map_err(|_| "controller lock poisoned")?;
        let version: i64 = db(connection.pragma_query_value(None, "user_version", |r| r.get(0)))?;
        if version == 1 {
            let tx = db(connection.transaction())?;
            db(tx.execute_batch(include_str!("codex_schema.sql")))?;
            db(tx.commit())?;
        } else if version != 2 {
            return Err("Codex registry schema unsupported".into());
        }
        Ok(Self { config })
    }
    pub fn drain(&self, _controller: &Controller) -> Result<(), String> {
        if !self.config.servers.is_empty() {
            return Err("native server registration not yet qualified".into());
        }
        Ok(())
    }
}
