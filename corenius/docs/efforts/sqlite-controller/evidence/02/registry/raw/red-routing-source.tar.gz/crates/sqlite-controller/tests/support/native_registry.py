"""MODEL_FREE_ACTUAL_PROTOCOL: real controller/supervisor/Codex/companion/tools.
The harness only admits/cancels through the controller, observes owned resources,
and supplies deterministic local Responses SSE bytes. It never dispatches workers.
"""
import pathlib,tempfile,json,subprocess,socket,hashlib,time,sys,threading,http.server,socketserver,os
BIN=pathlib.Path('/data02/home/philip.yang/.codex/packages/standalone/releases/0.159.3-x86_64-unknown-linux-musl/bin')
HERE=pathlib.Path(__file__).resolve().parents[2]
ORIGIN=pathlib.Path('/data02/home/philip.yang/devx/tmp/corenius-sqlite-topology-sms522gg')
TOKEN='operator-registry-secret'; SUPERVISOR='native-executor-secret'; CONTROL='native-controlplane-secret'
SCHEMA='e587a3d5ffab12e528589e14d385b04d1192b9ae6914ce008cd3ea507e5aa455'
def pin(path):return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def request(path,value):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(8);s.connect(str(path));s.sendall(json.dumps(value).encode()+b'\n');return json.loads(s.makefile('rb').readline())
def wait(predicate,seconds=20):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  result=predicate()
  if result:return result
  time.sleep(.04)
 raise AssertionError('behavior deadline')
class UnixHTTP(socketserver.ThreadingMixIn,socketserver.UnixStreamServer):daemon_threads=True
class Owned:
 def __init__(self,r):self.r=r;self.processes=[];self.records=[]
 def spawn(self,args,name,env):
  p=subprocess.Popen(args,env=env,stdout=open(self.r/(name+'.stdout'),'w'),stderr=open(self.r/(name+'.stderr'),'w'))
  self.processes.append(p);self.records.append({'name':name,'pid':p.pid,'start_stat':pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text(),'argv':args});return p
 def stop(self):
  for p in reversed(self.processes):
   if p.poll() is None:p.kill()
   p.wait(timeout=5)
  for record,p in zip(self.records,self.processes):record['exit']=p.returncode
  print('owned_fixture_resources',json.dumps(self.records),flush=True)

def run(topology):
 with tempfile.TemporaryDirectory(prefix='cnr-',dir='/tmp') as directory:
  r=pathlib.Path(directory);owned=Owned(r);release=threading.Event();counts={};counter_lock=threading.Lock();requests=[]
  for name in ['workers','controlplanes','t-exec','t-app','canonical']:(r/name).mkdir()
  (r/'canonical/protected').write_text('never mounted')
  guard=socket.socket();guard.bind(('127.0.0.1',0));guard.listen();guard_port=guard.getsockname()[1]
  class Handler(http.server.BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    assert self.path=='/v1/responses',self.path
    value=json.loads(self.rfile.read(int(self.headers['Content-Length'])));requests.append(value)
    text=json.dumps(value.get('input',[]));group='TASK_A' if 'TASK_A' in text else 'TASK_B' if 'TASK_B' in text else 'LEAD'
    assert release.wait(20),'fixture model response release deadline'
    with counter_lock:n=counts.get(group,0)+1;counts[group]=n
    item={'type':'message','id':f'msg-{group}-{n}','role':'assistant','content':[{'type':'output_text','text':'MODEL_FREE_FIXTURE_DONE'}]}
    if group!='LEAD' and n%3==1:
     probe=f"import pathlib,os,socket,json; w=pathlib.Path('/workspace'); forbidden={json.dumps([str(r),str(r/'controller.sock'),str(r/'state.db'),str(r/'canonical'),str(r/'controlplanes'),str(r/'workers/native-authority'),'/home/philip.yang','/root/.ssh'])}; assert all(not pathlib.Path(p).exists() for p in forbidden); s=socket.socket(); s.settimeout(.1); assert s.connect_ex(('127.0.0.1',{guard_port}))!=0; status=pathlib.Path('/proc/self/status').read_text(); assert 'CapEff:\\t0000000000000000' in status; (w/'{group}-shell').write_text('actual_native_shell'); (w/'{group}-probe').write_text(json.dumps({{'pid_namespace':os.readlink('/proc/self/ns/pid'),'net_namespace':os.readlink('/proc/self/ns/net'),'host_and_authority_absent':True,'host_tcp_blocked':True}}))"
     cmd='/usr/bin/python3 -c '+__import__('shlex').quote(probe)
     code='text(await tools.exec_command('+json.dumps({'cmd':cmd,'workdir':'/workspace','max_output_tokens':1000})+'));'
     item={'type':'custom_tool_call','id':f'ct-{group}-{n}','call_id':f'call-{group}-{n}','name':'exec','namespace':'functions','input':code}
    elif group!='LEAD' and n%3==2:
     patch='*** Begin Patch\n*** Add File: /workspace/'+group+'-patch\n+actual_native_patch\n*** End Patch'
     code='text(await tools.apply_patch('+json.dumps(patch)+'));'
     item={'type':'custom_tool_call','id':f'ct-{group}-{n}','call_id':f'call-{group}-{n}','name':'exec','namespace':'functions','input':code}
    response=f'response-{group}-{n}';events=[{'type':'response.created','response':{'id':response,'status':'in_progress'}},{'type':'response.output_item.done','output_index':0,'item':item},{'type':'response.completed','response':{'id':response,'status':'completed','output':[item],'usage':{'input_tokens':1,'output_tokens':1,'total_tokens':2}}}]
    body=''.join('data: '+json.dumps(event)+'\n\n' for event in events).encode();self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  provider=UnixHTTP(str(r/'provider.sock'),Handler);threading.Thread(target=provider.serve_forever,daemon=True).start()
  cfg=r/'runtime.toml';cfg.write_text((ORIGIN/'codex/config.toml').read_text().replace(str(ORIGIN/'catalog.json'),'/run/codex/catalog.json').replace('35361','8777'))
  assets={'binary':pin(BIN/'codex'),'companion':pin(BIN/'codex-code-mode-host'),'catalog':pin(ORIGIN/'catalog.json'),'config':pin(cfg),'launcher':pin(HERE/'support/codex_insula.py')}
  supervisor=pathlib.Path(sys.argv[1]).parent/'corenius-attempt-supervisor'
  try:
   for root,transport,kind,secret in [('workers','t-exec','exec',SUPERVISOR),('controlplanes','t-app','app',CONTROL)]:
    profile=dict(assets,kind=kind,transport_root=str(r/transport))
    if kind=='app':profile.update(provider_socket=str(r/'provider.sock'),executor_root=str(r/'t-exec'),own_executor_only=topology=='separate')
    config=r/(root+'.json');config.write_text(json.dumps({'root':str(r/root),'profile':{'executable':'/usr/bin/python3','args':['/run/codex/launcher.py'],'codex':profile}}))
    process=owned.spawn([str(supervisor),str(config),str(r/(root+'.sock'))],root,{'CORENIUS_SUPERVISOR_TOKEN':secret,'PATH':'/usr/bin:/bin'})
    def ready():
     assert process.poll() is None,(r/(root+'.stderr')).read_text()
     return (r/(root+'.sock')).exists()
    wait(ready,30)
   runtime_config=r/'controller-native.json';runtime_config.write_text(json.dumps({'schema_migration':'1-to-2','topology':topology,'transport_root':str(r/'t-app'),'servers':[{'id':'native','supervisor_socket':str(r/'controlplanes.sock'),'auth_ref':'CONTROLPLANE_SECRET','transport_root':str(r/'t-app'),'worker_supervisor_socket':str(r/'workers.sock'),'worker_auth_ref':'CORENIUS_SUPERVISOR_TOKEN','worker_transport_root':str(r/'t-exec'),'schema_digest':SCHEMA}]}))
   env={'PATH':'/usr/bin:/bin','CORENIUS_OPERATOR_TOKEN':TOKEN,'CORENIUS_CODEX_CONFIG':str(runtime_config),'CORENIUS_SUPERVISOR_SOCKET':str(r/'workers.sock'),'CORENIUS_SUPERVISOR_TOKEN':SUPERVISOR,'CONTROLPLANE_SECRET':CONTROL}
   controller=owned.spawn([sys.argv[1],str(r/'state.db'),str(r/'controller.sock')],'controller',env)
   def startup():
    assert controller.poll() is None,(r/'controller.stderr').read_text()
    return (r/'controller.sock').exists()
   wait(startup)
   auth={'principal':'operator','token':TOKEN}
   def query(kind):
    value=request(r/'controller.sock',{'auth':auth,'project':'p','query':{'kind':kind,'args':{}}});assert 'ok' in value,value;return value['ok']
   def command(kind,args):
    for retry in range(8):
     rev=0 if kind=='create_project' else query('snapshot')['revision']
     value=request(r/'controller.sock',{'auth':auth,'project':'p','command':{'kind':kind,'args':args,'expected_revision':rev,'idempotency_key':str(__import__('uuid').uuid4())}})
     if 'ok' in value:return value['ok']['result']
     assert 'revision' in value.get('error',''),value
    raise AssertionError('command revision contention')
   command('create_project',{'name':'p','base':'0123456789abcdef0123456789abcdef01234567'})
   grants=[]
   for task in ['TASK_A','TASK_B']:
    command('create_task',{'task':task,'work_ref':{'deployment':'fixture','project':'p','item':task},'source_revision':'r1','brief':task+' MODEL_FREE_ACTUAL_PROTOCOL'})
    grants.append(command('admit',{'task':task}))
   def bound():
    registry=query('codex_registry')
    return registry if len(registry['bindings'])==2 and all(b['document'].get('thread_id') for b in registry['bindings']) else False
   registry=wait(bound,8)
   assert query('snapshot')['occupied_slots']==2
   print('actual_bound_registry',topology,json.dumps(registry),flush=True)
   release.set()
   for grant,task in zip(grants,['TASK_A','TASK_B']):
    workspace=r/'workers'/grant['attempt']/'workspace'
    wait(lambda:(workspace/(task+'-shell')).exists() and (workspace/(task+'-patch')).exists(),20)
    assert not any((workspace/(peer+'-shell')).exists() for peer in ['TASK_A','TASK_B'] if peer!=task)
    print('actual_native_effects',topology,task,(workspace/(task+'-probe')).read_text(),flush=True)
   for grant in grants:command('cancel_attempt',{'attempt':grant['attempt']})
   wait(lambda:query('snapshot')['occupied_slots']==0)
   print('controller_owned_cancellation_confirmed',topology,flush=True)
  finally:
   release.set();owned.stop();provider.shutdown();provider.server_close();guard.close()
   for log in r.glob('*.stderr'):
    if log.stat().st_size:print('owned_log',log.name,log.read_text()[-3000:],flush=True)
for topology in ['shared','separate']:run(topology)
