//! Bounded authenticated native WebSocket transport over a fixed qualified Unix bridge.
use base64::{Engine, engine::general_purpose::STANDARD};
use serde_json::{Value, json};
use sha1::{Digest, Sha1};
use std::{
    io::{Read, Write},
    os::unix::net::UnixStream,
    path::Path,
    time::{Duration, Instant},
};
use uuid::Uuid;
pub struct NativeWs {
    stream: UnixStream,
    sequence: u64,
    pending: Vec<Value>,
}
impl NativeWs {
    pub fn connect(path: &Path, token: &str, start: &str) -> Result<Self, String> {
        if start.parse::<u64>().is_err() || token.contains(['\r', '\n']) {
            return Err("native connection identity refused".into());
        }
        let mut stream = UnixStream::connect(path).map_err(|e| e.to_string())?;
        stream
            .set_read_timeout(Some(Duration::from_secs(8)))
            .map_err(|e| e.to_string())?;
        stream
            .set_write_timeout(Some(Duration::from_secs(8)))
            .map_err(|e| e.to_string())?;
        let key = STANDARD.encode(Uuid::new_v4().as_bytes());
        write!(stream,"GET /?corenius_start={start} HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: {key}\r\nAuthorization: Bearer {token}\r\n\r\n").map_err(|e|e.to_string())?;
        let mut header = Vec::new();
        let mut byte = [0];
        while !header.ends_with(b"\r\n\r\n") {
            if header.len() > 16384 {
                return Err("native upgrade bound".into());
            }
            stream.read_exact(&mut byte).map_err(|e| e.to_string())?;
            header.push(byte[0]);
        }
        let header = String::from_utf8(header).map_err(|e| e.to_string())?;
        let accept = STANDARD.encode(Sha1::digest(format!(
            "{key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        )));
        if !header.starts_with("HTTP/1.1 101 ")
            || !header.lines().any(|l| {
                l.split_once(':').is_some_and(|(k, v)| {
                    k.eq_ignore_ascii_case("sec-websocket-accept") && v.trim() == accept
                })
            })
        {
            return Err("native websocket upgrade refused".into());
        }
        Ok(Self {
            stream,
            sequence: 0,
            pending: Vec::new(),
        })
    }
    fn send(&mut self, opcode: u8, bytes: &[u8]) -> Result<(), String> {
        let mask = *Uuid::new_v4().as_bytes();
        let mut frame = vec![0x80 | opcode];
        if bytes.len() < 126 {
            frame.push(0x80 | bytes.len() as u8)
        } else if bytes.len() <= 65535 {
            frame.push(0xfe);
            frame.extend_from_slice(&(bytes.len() as u16).to_be_bytes())
        } else {
            frame.push(0xff);
            frame.extend_from_slice(&(bytes.len() as u64).to_be_bytes())
        }
        frame.extend_from_slice(&mask[..4]);
        frame.extend(bytes.iter().enumerate().map(|(i, b)| b ^ mask[i % 4]));
        self.stream.write_all(&frame).map_err(|e| e.to_string())
    }
    fn receive(&mut self) -> Result<Value, String> {
        let mut body = Vec::new();
        let mut started = false;
        loop {
            let mut header = [0; 2];
            self.stream
                .read_exact(&mut header)
                .map_err(|e| e.to_string())?;
            if header[0] & 0x70 != 0 || header[1] & 0x80 != 0 {
                return Err("native frame flags refused".into());
            }
            let opcode = header[0] & 15;
            let mut len = (header[1] & 127) as u64;
            if len == 126 {
                let mut b = [0; 2];
                self.stream.read_exact(&mut b).map_err(|e| e.to_string())?;
                len = u16::from_be_bytes(b) as u64
            } else if len == 127 {
                let mut b = [0; 8];
                self.stream.read_exact(&mut b).map_err(|e| e.to_string())?;
                len = u64::from_be_bytes(b)
            }
            if len > 4 * 1024 * 1024 || body.len() + len as usize > 4 * 1024 * 1024 {
                return Err("native frame bound".into());
            }
            let mut payload = vec![0; len as usize];
            self.stream
                .read_exact(&mut payload)
                .map_err(|e| e.to_string())?;
            match opcode {
                8 => return Err("native connection closed".into()),
                9 => {
                    self.send(10, &payload)?;
                    continue;
                }
                10 => continue,
                1 if !started => started = true,
                0 if started => {}
                _ => return Err("native opcode refused".into()),
            }
            body.extend(payload);
            if header[0] & 0x80 != 0 {
                return serde_json::from_slice(&body).map_err(|e| e.to_string());
            }
        }
    }
    pub fn rpc(&mut self, method: &str, params: Value) -> Result<Value, String> {
        eprintln!("native RPC send {method}");
        self.sequence += 1;
        let id = format!("controller-{}", self.sequence);
        self.send(
            1,
            &serde_json::to_vec(&json!({"id":id,"method":method,"params":params}))
                .map_err(|e| e.to_string())?,
        )?;
        let deadline = Instant::now() + Duration::from_secs(8);
        loop {
            if Instant::now() > deadline {
                return Err("native RPC deadline; acknowledgement unknown".into());
            }
            let value = self.receive()?;
            if value.get("method").is_none() && value["id"] == id {
                if let Some(error) = value.get("error") {
                    return Err(format!("native RPC refused: {error}"));
                }
                eprintln!("native RPC received {method}");
                return value
                    .get("result")
                    .cloned()
                    .ok_or("native reply result missing".into());
            }
            eprintln!("native event {}", value["method"]);
            self.pending.push(value);
            if self.pending.len() > 1024 {
                return Err("native event buffer bound".into());
            }
        }
    }
    pub fn notify(&mut self, method: &str, params: Value) -> Result<(), String> {
        self.send(
            1,
            &serde_json::to_vec(&json!({"method":method,"params":params}))
                .map_err(|e| e.to_string())?,
        )
    }
    pub fn take_events(&mut self) -> Vec<Value> {
        std::mem::take(&mut self.pending)
    }
}
