use corenius_sqlite_controller::Controller;
use serde_json::json;
use std::process::Command;

#[test]
fn native_registry_is_a_durable_authenticated_controller_projection() {
    let native = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_init.py"
        ))
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&native.stdout));
    assert!(
        native.status.success(),
        "{}",
        String::from_utf8_lossy(&native.stderr)
    );
    let root = tempfile::tempdir().unwrap();
    let controller =
        Controller::open(root.path().join("state.db"), "operator-registry-secret").unwrap();
    let registry = controller.handle(json!({"auth":{"principal":"operator","token":"operator-registry-secret"},"project":"registry","query":{"kind":"codex_registry","args":{}}}));
    assert!(
        registry.is_ok(),
        "qualified native registry projection must exist: {registry:?}"
    );
    let refused = controller.handle(json!({"auth":{"principal":"operator","token":"wrong"},"project":"registry","query":{"kind":"codex_registry","args":{}}}));
    assert!(refused.is_err());
}

#[test]
fn configured_native_topologies_are_isolated_and_controller_owned() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_registry.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn pinned_native_services_use_supervised_private_network_profiles() {
    let output = Command::new("/usr/bin/python3")
        .arg(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/tests/support/native_profile.py"
        ))
        .arg(env!("CARGO_BIN_EXE_corenius-sqlite-controller"))
        .output()
        .unwrap();
    println!("{}", String::from_utf8_lossy(&output.stdout));
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}
