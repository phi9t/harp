//! Controller-owned native runtime registry. Journal commits precede external effects.
use crate::{
    Controller, db,
    native_ws::NativeWs,
    supervisor::{self, Binding},
};
use rusqlite::{OptionalExtension, params};
use serde::Deserialize;
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    fs,
    io::{BufRead, BufReader, Write},
    os::unix::net::UnixStream,
    path::{Path, PathBuf},
    sync::Mutex,
    time::Duration,
};
use uuid::Uuid;
const SCHEMA: &str = "e587a3d5ffab12e528589e14d385b04d1192b9ae6914ce008cd3ea507e5aa455";
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    schema_migration: String,
    topology: String,
    transport_root: PathBuf,
    servers: Vec<Server>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Server {
    id: String,
    supervisor_socket: PathBuf,
    auth_ref: String,
    transport_root: PathBuf,
    worker_supervisor_socket: PathBuf,
    worker_auth_ref: String,
    worker_transport_root: PathBuf,
    schema_digest: String,
}
struct Connected {
    incarnation: String,
    ws: NativeWs,
    subscribed: std::collections::HashSet<String>,
}
pub struct CodexRuntime {
    config: Config,
    connections: Mutex<HashMap<String, Connected>>,
}
fn text<'a>(v: &'a Value, key: &str) -> Result<&'a str, String> {
    v[key]
        .as_str()
        .ok_or_else(|| format!("native {key} missing"))
}
fn secret(reference: &str) -> Result<String, String> {
    if reference.is_empty()
        || !reference
            .bytes()
            .all(|b| b.is_ascii_uppercase() || b == b'_' || b.is_ascii_digit())
    {
        return Err("native auth reference refused".into());
    }
    let value = std::env::var(reference).map_err(|_| "native auth reference unavailable")?;
    if value.len() < 12 {
        return Err("native private credential required".into());
    }
    Ok(value)
}
impl CodexRuntime {
    pub fn open(path: &Path, controller: &Controller) -> Result<Self, String> {
        let config: Config = serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
        if config.schema_migration != "1-to-2"
            || !matches!(config.topology.as_str(), "shared" | "separate")
        {
            return Err("explicit Codex schema migration/topology required".into());
        }
        if !config.transport_root.is_absolute() || config.transport_root.starts_with("/usr") {
            return Err("private native transport root required".into());
        }
        fs::create_dir_all(&config.transport_root).map_err(|e| e.to_string())?;
        if config
            .transport_root
            .canonicalize()
            .map_err(|e| e.to_string())?
            != config.transport_root
        {
            return Err("native transport aliases refused".into());
        }
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(&config.transport_root, fs::Permissions::from_mode(0o700))
            .map_err(|e| e.to_string())?;
        if config.servers.len() > 1 {
            return Err("one configured native profile required".into());
        }
        for s in &config.servers {
            if s.id.is_empty()
                || s.schema_digest != SCHEMA
                || s.transport_root != config.transport_root
                || !s.supervisor_socket.is_absolute()
                || !s.worker_supervisor_socket.is_absolute()
                || !s.worker_transport_root.is_absolute()
            {
                return Err("native registered profile refused".into());
            }
            secret(&s.auth_ref)?;
            secret(&s.worker_auth_ref)?;
            if std::env::var_os("CORENIUS_SUPERVISOR_SOCKET").map(PathBuf::from)
                != Some(s.worker_supervisor_socket.clone())
                || s.worker_auth_ref != "CORENIUS_SUPERVISOR_TOKEN"
            {
                return Err("native worker effect owner mismatch".into());
            }
        }
        let mut c = controller
            .connection
            .lock()
            .map_err(|_| "controller lock poisoned")?;
        let version: i64 = db(c.pragma_query_value(None, "user_version", |r| r.get(0)))?;
        if version == 1 {
            let tx = db(c.transaction())?;
            db(tx.execute_batch(include_str!("codex_schema.sql")))?;
            db(tx.commit())?
        } else if version != 2 {
            return Err("Codex registry schema unsupported".into());
        }
        Ok(Self {
            config,
            connections: Mutex::new(HashMap::new()),
        })
    }
    pub fn drain(&self, controller: &Controller) -> Result<(), String> {
        let Some(server) = self.config.servers.first() else {
            return Ok(());
        };
        let rows = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let mut stmt=db(c.prepare("SELECT a.id,a.project,a.scope_epoch,a.base,a.brief,a.cancel_requested,a.state,o.id,b.body FROM attempts a JOIN operations o ON o.attempt=a.id AND o.kind='start' JOIN briefs b ON b.id=a.brief WHERE a.state<>'exited'"))?;
            let rows = db(stmt.query_map([], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, i64>(2)?,
                    r.get::<_, String>(3)?,
                    r.get::<_, String>(4)?,
                    r.get::<_, i64>(5)?,
                    r.get::<_, String>(6)?,
                    r.get::<_, String>(7)?,
                    r.get::<_, String>(8)?,
                ))
            }))?;
            rows.collect::<rusqlite::Result<Vec<_>>>()
                .map_err(|e| e.to_string())?
        };
        for (attempt, project, epoch, base, brief, cancelled, state, operation, body) in rows {
            if cancelled != 0 || state != "running" {
                continue;
            }
            let binding = Binding {
                project: project.clone(),
                attempt: attempt.clone(),
                operation,
                scope_epoch: epoch,
                base,
                brief,
            };
            if let Err(error) = self.bind_actor(
                controller,
                server,
                &binding,
                &body,
                "attempt",
                &format!("worker:{}:{}", binding.attempt, binding.scope_epoch),
            ) {
                eprintln!("native reconcile {attempt}: {error}");
            }
        }
        self.drain_leads(controller, server)?;
        Ok(())
    }
    fn drain_leads(&self, controller: &Controller, server: &Server) -> Result<(), String> {
        let projects = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let mut stmt =
                db(c.prepare("SELECT id,lead_epoch,base FROM projects WHERE lead_epoch>0"))?;
            let rows = db(stmt.query_map([], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, i64>(1)?,
                    r.get::<_, String>(2)?,
                ))
            }))?;
            rows.collect::<rusqlite::Result<Vec<_>>>()
                .map_err(|e| e.to_string())?
        };
        for (project, epoch, base) in projects {
            let id = format!("lead:{project}:{epoch}");
            let binding = {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                let raw: Option<String> = db(c
                    .query_row(
                        "SELECT document FROM codex_bindings WHERE id=?1",
                        [&id],
                        |r| r.get(0),
                    )
                    .optional())?;
                if let Some(raw) = raw {
                    let doc: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
                    serde_json::from_value(doc["executor_effect_binding"].clone())
                        .map_err(|e| e.to_string())?
                } else {
                    let binding = Binding {
                        project: project.clone(),
                        attempt: Uuid::new_v4().to_string(),
                        operation: Uuid::new_v4().to_string(),
                        scope_epoch: epoch,
                        base,
                        brief: format!("lead-authority:{epoch}"),
                    };
                    let doc = json!({"executor_effect_binding":binding,"ui_input_ready":false});
                    db(c.execute(
                        "INSERT INTO codex_bindings VALUES(?1,?2,'lead',NULL,?3,?4,'prepared')",
                        params![id, project, epoch, doc.to_string()],
                    ))?;
                    binding
                }
            };
            let token = secret(&server.worker_auth_ref)?;
            if supervisor::call(&server.worker_supervisor_socket, &token, "lookup", &binding)?
                .is_none()
            {
                supervisor::call(&server.worker_supervisor_socket, &token, "start", &binding)?;
            }
            if let Err(error) = self.bind_actor(
                controller,
                server,
                &binding,
                "LEAD MODEL_FREE_INITIAL_CONTEXT",
                "lead",
                &id,
            ) {
                eprintln!("native lead reconcile: {error}");
            }
        }
        Ok(())
    }
    fn bind_actor(
        &self,
        controller: &Controller,
        server: &Server,
        worker: &Binding,
        body: &str,
        role: &str,
        id: &str,
    ) -> Result<(), String> {
        let executor = supervisor::native_lookup(
            &server.worker_supervisor_socket,
            &secret(&server.worker_auth_ref)?,
            worker,
        )?;
        if executor["runtime"]["kind"] != "exec"
            || executor["runtime"]["endpoint"]
                != json!(
                    server
                        .worker_transport_root
                        .join(&worker.attempt)
                        .join("native.sock")
                )
        {
            return Err("registered executor endpoint mismatch".into());
        }
        let mut document = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let prior: Option<String> = db(c
                .query_row(
                    "SELECT document FROM codex_bindings WHERE id=?1",
                    [id],
                    |r| r.get(0),
                )
                .optional())?;
            match prior {
                Some(raw) => serde_json::from_str(&raw).map_err(|e| e.to_string())?,
                None => {
                    let value = json!({"server_id":if self.config.topology=="shared"{server.id.clone()}else{format!("{}:{}",server.id,worker.attempt)},"executor":executor["runtime"],"executor_execution":executor["execution"],"ui_input_ready":false});
                    db(c.execute(
                        "INSERT INTO codex_bindings VALUES(?1,?2,?6,?3,?4,?5,'preparing')",
                        params![
                            id,
                            worker.project,
                            if role == "attempt" {
                                Some(&worker.attempt)
                            } else {
                                None
                            },
                            worker.scope_epoch,
                            value.to_string(),
                            role
                        ],
                    ))?;
                    value
                }
            }
        };
        if document["executor_execution"].is_null() {
            document["executor_execution"] = executor["execution"].clone();
            document["executor"] = executor["runtime"].clone();
            document["server_id"] = json!(if self.config.topology == "shared" {
                server.id.clone()
            } else {
                format!("{}:{}", server.id, worker.attempt)
            });
            self.save_binding(controller, id, &document, "preparing")?;
        }
        if document["executor_execution"]["handle"] != executor["execution"]["handle"]
            || document["executor"]["workspace_identity"]
                != executor["runtime"]["workspace_identity"]
        {
            return Err("durable executor binding mismatch".into());
        }
        let server_id = text(&document, "server_id")?.to_string();
        let app_binding = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let raw: Option<String> = db(c
                .query_row(
                    "SELECT document FROM codex_servers WHERE id=?1",
                    [&server_id],
                    |r| r.get(0),
                )
                .optional())?;
            if let Some(raw) = raw {
                let value: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
                serde_json::from_value(value["effect_binding"].clone())
                    .map_err(|e| e.to_string())?
            } else {
                let binding = Binding {
                    project: worker.project.clone(),
                    attempt: if self.config.topology == "shared" {
                        Uuid::new_v4().to_string()
                    } else {
                        worker.attempt.clone()
                    },
                    operation: Uuid::new_v4().to_string(),
                    scope_epoch: worker.scope_epoch,
                    base: worker.base.clone(),
                    brief: worker.brief.clone(),
                };
                let value = json!({"effect_binding":binding,"profile":server.id,"schema_digest":server.schema_digest,"auth_ref":server.auth_ref,"topology":self.config.topology});
                db(c.execute(
                    "INSERT INTO codex_servers VALUES(?1,?2,'prepared')",
                    params![server_id, value.to_string()],
                ))?;
                binding
            }
        };
        let token = secret(&server.auth_ref)?;
        let execution =
            match supervisor::call(&server.supervisor_socket, &token, "lookup", &app_binding)? {
                Some(e) => e,
                None => supervisor::call(&server.supervisor_socket, &token, "start", &app_binding)?
                    .ok_or("native server effect absent")?,
            };
        if execution.state != "running" {
            return Err("native server effect not live".into());
        }
        let app = supervisor::native_lookup(&server.supervisor_socket, &token, &app_binding)?;
        if app["runtime"]["kind"] != "app"
            || app["runtime"]["endpoint"]
                != json!(
                    server
                        .transport_root
                        .join(&app_binding.attempt)
                        .join("native.sock")
                )
            || app["runtime"]["own_executor_only"] != json!(self.config.topology == "separate")
        {
            return Err("native server profile/topology mismatch".into());
        }
        if !document["server_store"].is_null()
            && document["server_store"] != app["runtime"]["store_id"]
        {
            return Err("native persistent store generation mismatch".into());
        }
        let incarnation = text(&app["runtime"], "incarnation")?;
        if document["server_incarnation"] != incarnation {
            document["ui_input_ready"] = json!(false);
            self.save_binding(controller, &id, &document, "reconciling")?;
        }
        let mut connections = self
            .connections
            .lock()
            .map_err(|_| "native connection lock poisoned")?;
        if connections
            .get(&server_id)
            .is_none_or(|v| v.incarnation != incarnation)
        {
            let mut ws = NativeWs::connect(
                Path::new(text(&app["runtime"], "endpoint")?),
                text(&app, "capability")?,
                text(&app["runtime"], "runtime_start")?,
            )?;
            let ready=ws.rpc("initialize",json!({"clientInfo":{"name":"corenius-controller","version":"0.1.0"},"capabilities":{"experimentalApi":true}}))?;
            if !text(&ready, "userAgent")?.contains("0.159.3") {
                return Err("native initialize version mismatch".into());
            }
            ws.notify("initialized", json!({}))?;
            connections.insert(
                server_id.clone(),
                Connected {
                    incarnation: incarnation.into(),
                    ws,
                    subscribed: std::collections::HashSet::new(),
                },
            );
        }
        let connected = connections.get_mut(&server_id).unwrap();
        if let Some(thread) = document["thread_id"].as_str()
            && !connected.subscribed.contains(thread)
        {
            let restored = self.mutation(
                controller,
                &id,
                &worker.project,
                "thread/resume",
                &json!({"threadId":thread}),
                &mut connected.ws,
            )?;
            if restored["thread"]["id"] != thread {
                return Err("native resume thread mismatch".into());
            }
            connected.subscribed.insert(thread.into());
            document["recovery_state"] = json!("remote_registered_input_blocked");
            document["ui_input_ready"] = json!(false);
            document["resumed_environments"] = restored["thread"]["environments"].clone();
            self.save_binding(controller, &id, &document, "reconciling")?;
        }
        let result = self.configure_thread(
            controller,
            &id,
            &mut document,
            &mut connected.ws,
            &app,
            &executor,
            worker,
            body,
        );
        if let Some(thread) = document["thread_id"].as_str() {
            connected.subscribed.insert(thread.into());
        }
        if result.is_err() {
            connections.remove(&server_id);
        }
        result
    }
    fn dispatch_prepared(
        &self,
        controller: &Controller,
        id: &str,
        document: &mut Value,
        ws: &mut NativeWs,
        worker: &Binding,
    ) -> Result<(), String> {
        let operations = {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let mut stmt=db(c.prepare("SELECT id,kind,intent FROM codex_operations WHERE binding=?1 AND state='prepared' ORDER BY rowid"))?;
            let rows = db(stmt.query_map([id], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, String>(2)?,
                ))
            }))?;
            rows.collect::<rusqlite::Result<Vec<_>>>()
                .map_err(|e| e.to_string())?
        };
        for (operation, kind, raw) in operations {
            let intent: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
            {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                let allowed: i64 = if intent["role"] == "lead" {
                    db(c.query_row(
                        "SELECT COUNT(*) FROM projects WHERE id=?1 AND lead_epoch=?2",
                        params![worker.project, intent["authority_epoch"].as_i64()],
                        |r| r.get(0),
                    ))?
                } else {
                    db(c.query_row("SELECT COUNT(*) FROM attempts WHERE id=?1 AND project=?2 AND scope_epoch=?3 AND cancel_requested=0 AND state='running'",params![worker.attempt,worker.project,worker.scope_epoch],|r|r.get(0)))?
                };
                let principal_allowed:i64=db(c.query_row("SELECT COUNT(*) FROM principals r LEFT JOIN projects p ON p.id=r.project WHERE r.id=?1 AND r.epoch=?2 AND (r.role='operator' OR (r.role='lead' AND r.epoch=p.lead_epoch))",params![intent["principal"].as_str(),intent["principal_epoch"].as_i64()],|r|r.get(0)))?;
                if allowed != 1 || principal_allowed != 1 {
                    db(c.execute(
                        "UPDATE codex_operations SET state='failed',observation=?2 WHERE id=?1",
                        params![operation, json!({"error":"authority revoked"}).to_string()],
                    ))?;
                    continue;
                }
                db(c.execute(
                    "UPDATE codex_operations SET state='applying' WHERE id=?1",
                    [&operation],
                ))?;
            }
            let native_kind = match kind.as_str() {
                "codex_turn" => "turn/start",
                "codex_steer" => "turn/steer",
                "codex_interrupt" => "turn/interrupt",
                _ => return Err("native operation kind refused".into()),
            };
            let mut params = json!({"threadId":document["thread_id"]});
            if kind != "codex_interrupt" {
                params["input"] = json!([{"type":"text","text":intent["text"],"text_elements":[]}]);
            }
            if kind == "codex_turn" {
                params["environments"] = json!([{"environmentId":document["environment_id"],"cwd":"/workspace","runtimeWorkspaceRoots":["/workspace"]}]);
                params["clientUserMessageId"] = json!(operation);
            } else if intent["expected_turn"] != document["turn_id"] {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.execute(
                    "UPDATE codex_operations SET state='failed',observation=?2 WHERE id=?1",
                    params![operation, json!({"error":"stale turn"}).to_string()],
                ))?;
                continue;
            } else if kind == "codex_steer" {
                params["expectedTurnId"] = document["turn_id"].clone();
            } else {
                params["turnId"] = document["turn_id"].clone();
            }
            let result = ws.rpc(native_kind, params);
            {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                let (state, observation) = match &result {
                    Ok(v) => ("confirmed", v.clone()),
                    Err(e) if e.starts_with("native RPC refused:") => {
                        ("failed", json!({"error":e}))
                    }
                    Err(e) => ("unknown", json!({"error":e})),
                };
                db(c.execute(
                    "UPDATE codex_operations SET state=?2,observation=?3 WHERE id=?1",
                    params![operation, state, observation.to_string()],
                ))?;
            }
            if kind == "codex_turn" {
                let value = result?;
                document["turn_id"] = value["turn"]["id"].clone();
            }
        }
        Ok(())
    }
    fn save_binding(
        &self,
        controller: &Controller,
        id: &str,
        document: &Value,
        state: &str,
    ) -> Result<(), String> {
        let c = controller
            .connection
            .lock()
            .map_err(|_| "controller lock poisoned")?;
        db(c.execute(
            "UPDATE codex_bindings SET document=?2,state=?3 WHERE id=?1",
            params![id, document.to_string(), state],
        ))?;
        Ok(())
    }
    fn mutation(
        &self,
        controller: &Controller,
        id: &str,
        project: &str,
        kind: &str,
        intent: &Value,
        ws: &mut NativeWs,
    ) -> Result<Value, String> {
        let operation = Uuid::new_v4().to_string();
        {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            db(c.execute(
                "INSERT INTO codex_operations VALUES(?1,?2,?3,?4,'applying',?5,NULL)",
                params![operation, project, id, kind, intent.to_string()],
            ))?;
        }
        let result = ws.rpc(kind, intent.clone());
        {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let (state, observation) = match &result {
                Ok(value) => ("confirmed", value.clone()),
                Err(error) => ("unknown", json!({"error":error})),
            };
            db(c.execute(
                "UPDATE codex_operations SET state=?2,observation=?3 WHERE id=?1",
                params![operation, state, observation.to_string()],
            ))?;
        }
        result
    }
    fn configure_thread(
        &self,
        controller: &Controller,
        id: &str,
        document: &mut Value,
        ws: &mut NativeWs,
        app: &Value,
        executor: &Value,
        worker: &Binding,
        body: &str,
    ) -> Result<(), String> {
        let incarnation = text(&app["runtime"], "incarnation")?;
        if document["server_incarnation"] != incarnation
            || document["executor"]["incarnation"] != executor["runtime"]["incarnation"]
        {
            let mut stream = UnixStream::connect(text(&app["runtime"], "control_endpoint")?)
                .map_err(|e| e.to_string())?;
            stream
                .set_read_timeout(Some(Duration::from_secs(1)))
                .map_err(|e| e.to_string())?;
            writeln!(stream,"{}",json!({"token":app["capability"],"action":"executor_bridge","attempt":worker.attempt})).map_err(|e|e.to_string())?;
            let mut reply = String::new();
            BufReader::new(stream)
                .read_line(&mut reply)
                .map_err(|e| e.to_string())?;
            let reply: Value = serde_json::from_str(&reply).map_err(|e| e.to_string())?;
            let url = format!(
                "{}/?corenius_start={}",
                text(&reply["ok"], "url")?,
                text(&executor["runtime"], "runtime_start")?
            );
            let environment_id = format!(
                "executor-{}-{}",
                worker.attempt,
                text(&executor["runtime"], "runtime_start")?
            );
            // Plaintext native capability remains transport-only, never enters intent/observation storage.
            let safe = json!({"environmentId":environment_id,"execServerUrl":url,"auth_ref":executor["runtime"]["auth_ref"],"executor_incarnation":executor["runtime"]["incarnation"]});
            let op = Uuid::new_v4().to_string();
            {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.execute("INSERT INTO codex_operations VALUES(?1,?2,?3,'environment/add','applying',?4,NULL)",params![op,worker.project,id,safe.to_string()]))?;
            }
            let added=ws.rpc("environment/add",json!({"environmentId":environment_id,"execServerUrl":url,"authBearerToken":executor["capability"],"connectTimeoutMs":1500}));
            {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.execute(
                    "UPDATE codex_operations SET state=?2,observation=?3 WHERE id=?1",
                    params![
                        op,
                        if added.is_ok() {
                            "confirmed"
                        } else {
                            "unknown"
                        },
                        json!({"registered":added.is_ok()}).to_string()
                    ],
                ))?;
            }
            added?;
            document["environment_id"] = json!(environment_id);
            document["server_incarnation"] = json!(incarnation);
            document["server_store"] = app["runtime"]["store_id"].clone();
            document["server_execution"] = app["execution"].clone();
            document["executor"] = executor["runtime"].clone();
            self.save_binding(controller, id, document, "remote_registered")?;
        }
        let status = ws.rpc(
            "environment/status",
            json!({"environmentId":document["environment_id"]}),
        )?;
        if status["status"] != "ready" {
            return Err(format!("remote executor not ready: {status}"));
        }
        let environments = json!([{"environmentId":document["environment_id"],"cwd":"/workspace","runtimeWorkspaceRoots":["/workspace"]}]);
        if document["thread_id"].is_null() {
            let prior_unknown = {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.query_row("SELECT COUNT(*) FROM codex_operations WHERE binding=?1 AND kind='thread/start' AND state<>'confirmed'",[id],|r|r.get::<_,i64>(0)))?
            };
            if prior_unknown != 0 {
                return Err("thread creation acknowledgement unknown; no replay".into());
            }
            let result=self.mutation(controller,id,&worker.project,"thread/start",&json!({"model":"gpt-6-sol","modelProvider":"corenius-relay","cwd":"/workspace","approvalPolicy":"never","sandbox":"danger-full-access","environments":environments}),ws)?;
            document["thread_id"] = result["thread"]["id"].clone();
            if document["thread_id"].as_str().is_none() {
                return Err("native thread identity missing".into());
            }
            self.save_binding(controller, id, document, "thread_bound")?;
        }
        if document["turn_id"].is_null() {
            let prior_unknown = {
                let c = controller
                    .connection
                    .lock()
                    .map_err(|_| "controller lock poisoned")?;
                db(c.query_row("SELECT COUNT(*) FROM codex_operations WHERE binding=?1 AND kind='turn/start' AND state<>'confirmed'",[id],|r|r.get::<_,i64>(0)))?
            };
            if prior_unknown != 0 {
                return Err("turn acknowledgement unknown; no replay".into());
            }
            let result=self.mutation(controller,id,&worker.project,"turn/start",&json!({"threadId":document["thread_id"],"clientUserMessageId":Uuid::new_v4().to_string(),"input":[{"type":"text","text":body,"text_elements":[]}],"environments":environments}),ws)?;
            document["turn_id"] = result["turn"]["id"].clone();
            if document["turn_id"].as_str().is_none() {
                return Err("native turn identity missing".into());
            }
            self.save_binding(controller, id, document, "turn_bound")?;
        }
        let observed = ws.rpc(
            "thread/read",
            json!({"threadId":document["thread_id"],"includeTurns":true}),
        )?;
        document["observed_environments"] = observed["thread"]["environments"].clone();
        document["ui_input_ready"] = json!(observed["thread"]["environments"] == environments);
        if document["ui_input_ready"] == true {
            document["recovery_state"] = json!("remote_validated");
        }
        self.dispatch_prepared(controller, id, document, ws, worker)?;
        document["native_activity"] = json!(ws.take_events());
        self.save_binding(controller, id, document, "bound")?;
        {
            let c = controller
                .connection
                .lock()
                .map_err(|_| "controller lock poisoned")?;
            let value = json!({"effect_binding":app["execution"]["binding"],"execution":app["execution"],"runtime":app["runtime"],"schema_digest":SCHEMA,"topology":self.config.topology});
            db(c.execute(
                "UPDATE codex_servers SET document=?2,state='qualified' WHERE id=?1",
                params![document["server_id"].as_str(), value.to_string()],
            ))?;
        }
        Ok(())
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct TurnCommand {
    attempt: Option<String>,
    role: Option<String>,
    text: Option<String>,
    expected_turn: Option<String>,
    expected_binding: Option<Value>,
}
pub(super) fn prepare(
    tx: &rusqlite::Transaction<'_>,
    p: &crate::Principal,
    project: &str,
    kind: &str,
    args: &Value,
) -> Result<Value, String> {
    let input: TurnCommand = serde_json::from_value(args.clone())
        .map_err(|e| format!("native command arguments: {e}"))?;
    let role = input.role.as_deref().unwrap_or("attempt");
    if !matches!(role, "attempt" | "lead") || p.role == "attempt" {
        return Err("native actor authority refused".into());
    }
    let (id, epoch, document): (String, i64, String) = if role == "lead" {
        if input.attempt.is_some() {
            return Err("lead attempt selector refused".into());
        }
        db(tx.query_row("SELECT b.id,b.authority_epoch,b.document FROM codex_bindings b JOIN projects p ON p.id=b.project AND p.lead_epoch=b.authority_epoch WHERE b.project=?1 AND b.role='lead'",[project],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?))))?
    } else {
        let attempt = input.attempt.as_deref().ok_or("attempt required")?;
        db(tx.query_row("SELECT b.id,b.authority_epoch,b.document FROM codex_bindings b JOIN attempts a ON a.id=b.attempt AND a.scope_epoch=b.authority_epoch WHERE b.project=?1 AND b.attempt=?2 AND a.project=?1 AND a.cancel_requested=0 AND a.state='running'",params![project,attempt],|r|Ok((r.get(0)?,r.get(1)?,r.get(2)?))))?
    };
    let document: Value = serde_json::from_str(&document).map_err(|e| e.to_string())?;
    if let Some(expected) = input.expected_binding {
        let fields = expected
            .as_object()
            .ok_or("expected binding object required")?;
        for (key, value) in fields {
            if !matches!(
                key.as_str(),
                "thread_id" | "server_store" | "server_incarnation" | "environment_id"
            ) || &document[key] != value
            {
                return Err("native binding guard mismatch".into());
            }
        }
    }
    if kind != "codex_interrupt"
        && input
            .text
            .as_ref()
            .is_none_or(|t| t.is_empty() || t.len() > 65536)
    {
        return Err("native input text required".into());
    }
    if kind != "codex_turn" && input.expected_turn.as_deref() != document["turn_id"].as_str() {
        return Err("native expected turn mismatch".into());
    }
    let operation = Uuid::new_v4().to_string();
    let intent = json!({"role":role,"authority_epoch":epoch,"text":input.text,"expected_turn":input.expected_turn,"principal":p.id,"principal_epoch":p.epoch});
    db(tx.execute(
        "INSERT INTO codex_operations VALUES(?1,?2,?3,?4,'prepared',?5,NULL)",
        params![operation, project, id, kind, intent.to_string()],
    ))?;
    Ok(json!({"operation":operation,"binding":id,"state":"prepared"}))
}
