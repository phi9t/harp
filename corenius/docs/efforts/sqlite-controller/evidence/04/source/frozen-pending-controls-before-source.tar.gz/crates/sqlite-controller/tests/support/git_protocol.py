"""MODEL_FREE actual public SQLite/Git/supervisor/bwrap contract qualification.
All resources are unique local fixtures. No source/mainline/model/session effects.
"""
import concurrent.futures, hashlib, json, os, pathlib, select, signal, socket, subprocess, sys, tarfile, tempfile, time, uuid
BIN=pathlib.Path(sys.argv[1]).resolve(); HERE=pathlib.Path(__file__).resolve().parents[2]
TOKEN='operator-git-secret'; SUPERVISOR='git-supervisor-secret'
def pin(path):
 p=pathlib.Path(path);return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def wait(f,seconds=25):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  value=f()
  if value:return value
  time.sleep(.02)
 raise AssertionError('public behavior deadline')
def request(path,value):
 with socket.socket(socket.AF_UNIX) as s:
  s.settimeout(40);s.connect(str(path));s.sendall(json.dumps(value).encode()+b'\n');return json.loads(s.makefile('rb').readline())
def git(path,*args):
 p=subprocess.run(['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','-C',str(path),*args],env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_NO_REPLACE_OBJECTS':'1'},capture_output=True,text=True)
 assert p.returncode==0,(args,p.stderr);return p.stdout.strip()
class Fixture:
 def __init__(self,mode):
  self.temp=tempfile.TemporaryDirectory(prefix='g4-',dir='/tmp');self.r=pathlib.Path(self.temp.name);self.mode=mode;self.processes=[];self.records=[];self.namespaces={}
  try:self.setup()
  except BaseException:
   self.close();raise
 def setup(self):
  for d in ['authority','workers','canonical','seed']:(self.r/d).mkdir()
  git(self.r/'canonical','init','--bare','--template=')
  git(self.r/'seed','init','--template=')
  (self.r/'seed/README').write_text('bounded fixture base\n')
  git(self.r/'seed','add','README');git(self.r/'seed','-c','user.name=Fixture','-c','user.email=fixture@invalid','commit','-m','B')
  self.base=git(self.r/'seed','rev-parse','HEAD');git(self.r/'seed','push',str(self.r/'canonical'),self.base+':refs/heads/protected')
  (self.r/'secret').write_text('outside effect must remain unchanged')
  self.suite=self.r/'verification.py';self.suite.write_text('''import importlib.util,pathlib,sys,os
root=pathlib.Path('/workspace');mode=sys.argv[1];host=sys.argv[2]
assert not pathlib.Path(host).exists(), 'verifier must not see controller root'
assert not pathlib.Path('/root/.ssh').exists()
assert 'CapEff:\\t0000000000000000' in pathlib.Path('/proc/self/status').read_text()
for name in (['a','b'] if mode=='combined' else [mode]):
 spec=importlib.util.spec_from_file_location('task_'+name,root/('task_'+name+'.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 assert module.answer()==('A' if name=='a' else 'B'), 'fixed admitted task contract failed'
print('FIXED_CONTRACT_PASS',mode,'VERIFIER_OS_ISOLATED')
''')
  suites=[]
  for task in ['a','b']:
   suites += [{'id':task+'-initial','task':task,'base':self.base,'script':pin(self.suite),'args':[task,str(self.r)]},{'id':task+'-combined','task':task,'base':None,'script':pin(self.suite),'args':['combined',str(self.r)]}]
  policy={'project':'p','root':str(self.r/'authority'),'attempts_root':str(self.r/'workers'),'canonical':str(self.r/'canonical'),'protected_ref':'refs/heads/protected','git':pin('/usr/bin/git'),'python':pin('/usr/bin/python3'),'bubblewrap':pin('/usr/bin/bwrap'),'suites':suites}
  self.policy=self.r/'git.json';self.policy.write_text(json.dumps(policy))
  worker='''import pathlib,time,json,subprocess,os
s=pathlib.Path('/scratch');w=pathlib.Path('/workspace')
while not (s/'action.json').exists():time.sleep(.02)
a=json.loads((s/'action.json').read_text());name=a['task'];host=a['host'];pid=a['host_pid']
assert (w/'.git').is_dir(),'controller must provision complete Git before dispatch'
assert not (w/'.git/objects/info/alternates').exists()
assert not pathlib.Path(host).exists(),'canonical/controller path exposed'
try:os.kill(pid,0);raise AssertionError('controller signal authority exposed')
except ProcessLookupError:pass
code="import pathlib,os\\ndef answer():\\n try: pathlib.Path("+repr(host+'/secret')+").write_text('FORBIDDEN')\\n except (FileNotFoundError,PermissionError): print('CANDIDATE_OUTSIDE_EFFECT_DENIED')\\n else: raise AssertionError('verifier outside authority exposed')\\n return "+repr('A' if name=='a' else 'B')+"\\n"
if a.get('flood'):code=code.replace('def answer():','def answer():\\n print("x"*(26*1024*1024))')
(w/('task_'+name+'.py')).write_text(code)
def git(*args):return subprocess.run(['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','-C','/workspace',*args],check=True,capture_output=True,text=True).stdout.strip()
git('add','--all');git('-c','user.name=Worker','-c','user.email=worker@invalid','commit','-m','private '+name)
# Actual hostile worker-owned Git configuration and hook/upload-pack probes.
(w/'.git/hooks').mkdir(exist_ok=True);evil=w/'.git/hooks/evil';evil.write_text('#!/usr/bin/python3\\nimport pathlib\\ntry:pathlib.Path('+repr(host+'/secret')+').write_text("FORBIDDEN")\\nexcept (FileNotFoundError,PermissionError):pathlib.Path("/scratch/hostile-denied").write_text("outside denied")\\nelse:raise AssertionError("outside exposed")\\n');evil.chmod(0o700)
git('config','core.fsmonitor','/workspace/.git/hooks/evil')
subprocess.run(['/usr/bin/git','-C','/workspace','status','--porcelain'],capture_output=True)
subprocess.run(['/usr/bin/git','clone','--upload-pack=/workspace/.git/hooks/evil','/workspace','/scratch/hostile-clone'],capture_output=True)
assert (s/'hostile-denied').exists(),'malicious config/upload-pack probe must actually execute inside boundary'
(s/'ready').write_text(git('rev-parse','HEAD'))
while not (s/'finish').exists():
 if (s/'hostile.json').exists():
  h=json.loads((s/'hostile.json').read_text());f=w/'.git/hooks/filter';f.write_text(h['filter_code']);f.chmod(0o700)
  git('config','filter.hostile.clean',h['command']);(w/'.gitattributes').write_text('task_a.py filter=hostile\\n')
  p=w/'task_a.py';p.write_text(p.read_text().replace("return 'A'","return 'Z'"));os.utime(p,(time.time()+5,time.time()+5))
  (s/'hostile.json').unlink();(s/'hostile-installed').write_text('owned worker configured hostile clean filter')
 time.sleep(.02)
'''
  config={'root':str(self.r/'workers'),'profile':{'executable':'/usr/bin/python3','args':['-c',worker],'codex':None}}
  self.supervisor_config=self.r/'supervisor.json';self.supervisor_config.write_text(json.dumps(config))
  self.supervisor=self.spawn([str(BIN.parent/'corenius-attempt-supervisor'),str(self.supervisor_config),str(self.r/'supervisor.sock')],'supervisor',{'PATH':'/usr/bin:/bin','CORENIUS_SUPERVISOR_TOKEN':SUPERVISOR,'CORENIUS_GIT_CONFIG':str(self.policy)})
  wait(lambda:self.alive(self.supervisor,'supervisor') and (self.r/'supervisor.sock').exists())
  self.env={'PATH':'/usr/bin:/bin','CORENIUS_OPERATOR_TOKEN':TOKEN,'CORENIUS_GIT_CONFIG':str(self.policy),'CORENIUS_SUPERVISOR_SOCKET':str(self.r/'supervisor.sock'),'CORENIUS_SUPERVISOR_TOKEN':SUPERVISOR}
  self.controller=self.start_controller('controller')
  self.command('create_project',{'name':'p','base':self.base})
 def spawn(self,argv,name,env):
  p=subprocess.Popen(argv,env=env,stdout=open(self.r/(name+'.stdout'),'w'),stderr=open(self.r/(name+'.stderr'),'w'));fd=os.pidfd_open(p.pid)
  start=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().rsplit(') ',1)[1].split()[19]
  self.processes.append((p,fd));self.records.append({'name':name,'pid':p.pid,'start_ticks':start,'argv':argv});return p
 def alive(self,p,name):
  assert p.poll() is None,(name,(self.r/(name+'.stderr')).read_text());return True
 def start_controller(self,name):
  p=self.spawn([str(BIN),str(self.r/'state.db'),str(self.r/'controller.sock')],name,self.env)
  def ready():
   self.alive(p,name)
   try:return request(self.r/'controller.sock',{'auth':{'principal':'operator','token':TOKEN},'project':'p','query':{'kind':'storage_configuration','args':{}}}).get('ok')
   except (ConnectionRefusedError,FileNotFoundError,ConnectionResetError):return False
  wait(ready);return p
 def query(self,kind,args=None,auth=None):
  result=request(self.r/'controller.sock',{'auth':auth or {'principal':'operator','token':TOKEN},'project':'p','query':{'kind':kind,'args':args or {}}});assert 'ok' in result,result
  if kind=='snapshot':
   for a in result['ok']['attempts']:
    if a.get('observation'):
     try:e=json.loads(a['observation'])
     except ValueError:continue
     pid=e.get('namespace_init');start=e.get('init_start_ticks');key=(pid,start)
     if pid and key not in self.namespaces:
      try:
       fd=os.pidfd_open(pid);poll=select.poll();poll.register(fd,select.POLLIN);actual=pathlib.Path('/proc/'+str(pid)+'/stat').read_text().rsplit(') ',1)[1].split()[19]
       assert actual==start
       if not poll.poll(0):self.namespaces[key]=(fd,e)
       else:os.close(fd)
      except ProcessLookupError:pass
  return result['ok']
 def command(self,kind,args,auth=None,key=None,revision=None,allow_error=False):
  automatic=revision is None and key is None
  if revision is None:
   revision=0 if kind=='create_project' else self.query('snapshot')['revision']
  req={'auth':auth or {'principal':'operator','token':TOKEN},'project':'p','command':{'kind':kind,'args':args,'expected_revision':revision,'idempotency_key':key or str(uuid.uuid4())}}
  value=request(self.r/'controller.sock',req)
  for _ in range(25):
   if not automatic or 'revision conflict' not in value.get('error',''):break
   req['command']['expected_revision']=self.query('snapshot')['revision'];req['command']['idempotency_key']=str(uuid.uuid4());value=request(self.r/'controller.sock',req)
  if not allow_error:assert 'ok' in value,(kind,value)
  return value if allow_error else value['ok']['result']
 def admit(self,task):
  self.command('create_task',{'task':task,'work_ref':{'deployment':'fixture','project':'p','item':task},'source_revision':'r1','brief':'fixed bounded '+task+' contract; preserve existing peer work'})
  return self.command('admit',{'task':task})
 def ready(self,grant,task,flood=False):
  root=self.r/'workers'/grant['attempt'];wait(lambda:(root/'workspace/.git/objects').is_dir())
  (root/'scratch/action.json').write_text(json.dumps({'task':task,'host':str(self.r),'host_pid':self.controller.pid,'flood':flood}))
  wait(lambda:self.query('snapshot') and (root/'scratch/ready').exists());wait(lambda:next(a for a in self.query('snapshot')['attempts'] if a['id']==grant['attempt'])['state']=='running')
  return (root/'scratch/ready').read_text()
 def capture(self,grant):return self.command('capture_candidate',{'report':'worker report is evidence content, never verifier authority'},auth={'principal':grant['principal'],'token':grant['token']})
 def accept(self,c):
  v=self.command('verify_candidate',{'candidate':c['candidate']});assert v['verdict']=='pass',v
  accepted=self.command('accept_candidate',{'candidate':c['candidate'],'verification':v['verification']});return v,accepted
 def stop_attempt(self,grant):
  (self.r/'workers'/grant['attempt']/'scratch/finish').write_text('owned deterministic executor finish')
  wait(lambda:next(a for a in self.query('snapshot')['attempts'] if a['id']==grant['attempt'])['state']=='exited')
  e=next(a for a in self.query('snapshot')['attempts'] if a['id']==grant['attempt']);assert json.loads(e['observation'])['state']=='exited'
 def terminate(self,p):
  fd=next(fd for child,fd in self.processes if child is p)
  if p.poll() is None:signal.pidfd_send_signal(fd,signal.SIGKILL)
  p.wait(timeout=5)
 def close(self):
  # Qualify only namespace identities from this fixture's supervisor records,
  # including an early setup failure before the first snapshot was obtained.
  for path in (self.r/'workers').glob('*.json'):
   try:
    e=json.loads(path.read_text());pid=e.get('namespace_init');start=e.get('init_start_ticks');key=(pid,start)
    if not pid or key in self.namespaces:continue
    fd=os.pidfd_open(pid);stat=pathlib.Path('/proc/'+str(pid)+'/stat').read_text().rsplit(') ',1)[1].split();namespace=int(os.readlink('/proc/'+str(pid)+'/ns/pid').split('[')[1][:-1]);poll=select.poll();poll.register(fd,select.POLLIN)
    if stat[19]==start and namespace==e['pid_namespace'] and not poll.poll(0):self.namespaces[key]=(fd,e)
    else:os.close(fd)
   except (FileNotFoundError,ProcessLookupError):pass
  for p,fd in reversed(self.processes):
   if p.poll() is None:signal.pidfd_send_signal(fd,signal.SIGKILL)
   p.wait(timeout=5);os.close(fd)
  dispositions=[]
  for (pid,start),(fd,e) in self.namespaces.items():
   poll=select.poll();poll.register(fd,select.POLLIN);stopped=bool(poll.poll(0))
   if not stopped:signal.pidfd_send_signal(fd,signal.SIGKILL)
   terminated=bool(poll.poll(5000));os.close(fd);assert terminated
   dispositions.append({'pid':pid,'start_ticks':start,'handle':e['handle'],'pid_namespace':e['pid_namespace'],'stopped_before_fixture_cleanup':stopped,'whole_process_terminated':terminated})
  for record,(p,_) in zip(self.records,self.processes):record['exit']=p.returncode
  (self.r/'process-dispositions.json').write_text(json.dumps({'processes':self.records,'namespaces':dispositions},indent=2))
  root=HERE.parents[1]/'.scratch/sqlite-controller/04/fixtures';root.mkdir(parents=True,exist_ok=True)
  archive=root/(self.mode+'-'+self.r.name+'.tar.gz')
  with tarfile.open(archive,'w:gz') as a:a.add(self.r,arcname=self.r.name)
  print('retained_actual_fixture',json.dumps({'mode':self.mode,'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'processes':self.records,'namespaces':dispositions}),flush=True)
  self.temp.cleanup()
def normal():
 f=Fixture('normal')
 try:
  a=f.admit('a');b=f.admit('b');C=f.ready(a,'a');D=f.ready(b,'b')
  snapshot=f.query('snapshot');assert snapshot['occupied_slots']==2 and all(x['state']=='running' for x in snapshot['attempts'])
  for grant in [a,b]:
   repo=f.r/'workers'/grant['attempt']/'workspace';assert (repo/'.git').is_dir() and not (repo/'.git/objects/info/alternates').exists()
   assert os.stat(repo/'.git/objects').st_ino!=os.stat(f.r/'canonical/objects').st_ino
   assert all(os.stat(path).st_nlink==1 for path in (repo/'.git/objects').rglob('*') if path.is_file())
  assert os.stat(f.r/'workers'/a['attempt']/'workspace/.git').st_ino!=os.stat(f.r/'workers'/b['attempt']/'workspace/.git').st_ino
  inventory=f.query('workspace_inventory');assert len(inventory['workspaces'])==2 and not inventory['ref_drift'];assert all(w['ownership_drift'] is None for w in inventory['workspaces'])
  ca=f.capture(a);cb=f.capture(b);assert ca['commit']==C and cb['commit']==D and ca['base']==cb['base']==f.base
  for grant,c in [(a,ca),(b,cb)]:
   ev=f.query('candidate_evidence',{'candidate':c['candidate']});assert ev['candidate']['commit']==c['commit'];assert not ev['verification']
   assert f.command('verify_candidate',{'candidate':c['candidate']},auth={'principal':grant['principal'],'token':grant['token']},allow_error=True).get('error')
  va,_=f.accept(ca);vb,_=f.accept(cb)
  assert va['document']['materialization']!=vb['document']['materialization'] and all('/workers/' not in v['document']['materialization'] for v in [va,vb])
  assert f.command('accept_candidate',{'candidate':ca['candidate'],'verification':vb['verification']},allow_error=True).get('error')
  for extra in [{'bundle':'forged'},{'workspace':str(f.r/'canonical')},{'report_digest':'forged'}]:
   assert f.command('capture_candidate',dict({'report':'x'},**extra),auth={'principal':a['principal'],'token':a['token']},allow_error=True).get('error')
  assert (f.r/'secret').read_text()=='outside effect must remain unchanged'
  land=f.command('land_candidate',{'candidate':ca['candidate'],'expected_trunk':f.base});assert land['state']=='landed' and git(f.r/'canonical','rev-parse','refs/heads/protected')==C
  stale=f.command('land_candidate',{'candidate':cb['candidate'],'expected_trunk':f.base});assert stale['state']=='stale_base' and git(f.r/'canonical','rev-parse','refs/heads/protected')==C
  f.stop_attempt(a);f.stop_attempt(b)
  d2=f.command('admit',{'task':'b'});assert d2['base']==C and d2['attempt']!=b['attempt']
  D2=f.ready(d2,'b');c2=f.capture(d2);assert c2['commit']==D2 and c2['base']==C
  assert f.command('accept_candidate',{'candidate':c2['candidate'],'verification':vb['verification']},allow_error=True).get('error')
  v2,_=f.accept(c2);assert v2['document']['suite_id']=='b-combined'
  assert f.command('land_candidate',{'candidate':c2['candidate'],'expected_trunk':C})['state']=='landed';assert git(f.r/'canonical','rev-parse','refs/heads/protected')==D2
  old=f.query('candidate_evidence',{'candidate':cb['candidate']});assert old['candidate']['commit']==D and old['verification'][0]['id']==vb['verification']
  f.stop_attempt(d2)
  # Actual dirty and untracked preservation; failure is separately retryable.
  root=f.r/'workers'/d2['attempt'];(root/'workspace/untracked').write_text('preserve me')
  denied=f.command('retire_workspace',{'attempt':d2['attempt'],'retire_refs':['refs/heads/attempt']},allow_error=True);assert 'dirty/untracked' in denied['error'] and (root/'workspace/untracked').exists()
  # The fixture owns this newly generated file and explicitly retains/removes it.
  (f.r/'retained-untracked').write_bytes((root/'workspace/untracked').read_bytes());(root/'workspace/untracked').unlink()
  retired=f.command('retire_workspace',{'attempt':d2['attempt'],'retire_refs':['refs/heads/attempt']});assert retired['state']=='retired' and not root.exists()
  assert f.query('workspace_inventory')['workspaces'][-1]['cleanup_disposition']=='retired'
  assert f.command('capture_candidate',{'report':'stale'},auth={'principal':d2['principal'],'token':d2['token']},allow_error=True).get('error')
  print('private_candidates_C_D_stale_D2_combined_verification_serialized_FF_PASS',json.dumps({'B':f.base,'C':C,'D':D,'D2':D2,'C_proof':va,'D_proof':vb,'D2_proof':v2,'retirement':retired}),flush=True)
 finally:f.close()
def hostile():
 f=Fixture('hostile-scratch')
 try:
  a=f.admit('a');f.ready(a,'a');root=f.r/'workers'/a['attempt'];repo=root/'workspace'
  sentinel='owned-capture-sentinel-'+uuid.uuid4().hex;(f.r/'secret').write_text(sentinel)
  filter_code="""#!/usr/bin/python3
import os,pathlib,json,sys
host=sys.argv[1]
for name in ['/scratch/candidate.bundle','/scratch/ancestor']:
 try:os.symlink(host,name)
 except FileExistsError:pass
receipt={name:os.path.islink(name) for name in ['/scratch/candidate.bundle','/scratch/ancestor']}
try:pathlib.Path(host).read_bytes()
except (FileNotFoundError,PermissionError):receipt['outside_read_denied']=True
else:receipt['outside_read_denied']=False
pathlib.Path('/workspace/.git/hostile-scratch-receipt').write_text(json.dumps(receipt))
sys.stdout.buffer.write(sys.stdin.buffer.read())
"""
  # The actual supervised worker remains the sole Git writer; the outer fixture
  # only supplies its declared adversarial action through private scratch.
  (root/'scratch/hostile.json').write_text(json.dumps({'filter_code':filter_code,'command':'/usr/bin/python3 /workspace/.git/hooks/filter '+str(f.r/'secret')}))
  wait(lambda:(root/'scratch/hostile-installed').exists())
  result=f.command('capture_candidate',{'report':'actual hostile clean filter scratch replacement probe'},auth={'principal':a['principal'],'token':a['token']},allow_error=True)
  print('actual_hostile_capture_result',json.dumps(result),flush=True)
  receipt=json.loads((repo/'.git/hostile-scratch-receipt').read_text());assert all(receipt.values()),receipt
  assert (f.r/'secret').read_text()==sentinel
  secret_digest=hashlib.sha256(sentinel.encode()).hexdigest()
  assert not (f.r/'authority/artifacts'/secret_digest).exists()
  assert all(sentinel.encode() not in path.read_bytes() for path in (f.r/'authority/artifacts').iterdir())
  assert sentinel not in json.dumps(result) and secret_digest not in json.dumps(result)
  print('actual_hostile_clean_filter_final_and_ancestor_replacements_NO_HOST_READ_PASS',json.dumps({'receipt':receipt,'result':result,'outside_digest_not_retained':True}),flush=True)
  f.stop_attempt(a)
 finally:f.close()
def cancel_race():
 f=Fixture('capture-cancel-race')
 try:
  a=f.admit('a');f.ready(a,'a');f.terminate(f.controller)
  f.env['CORENIUS_TEST_GIT_CAPTURE_BARRIER']=str(f.r/'capture-barrier');f.controller=f.start_controller('controller-capture-barrier')
  (f.r/'capture-barrier').write_text('declared retained bytes before candidate publication')
  with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
   future=pool.submit(f.command,'capture_candidate',{'report':'race'},auth={'principal':a['principal'],'token':a['token']},allow_error=True)
   wait(lambda:(f.r/'capture-barrier.observed').exists())
   started=time.monotonic();f.command('cancel_attempt',{'attempt':a['attempt']});assert time.monotonic()-started<2,'cancellation must remain responsive during external Git capture'
   (f.r/'capture-barrier').unlink();outcome=future.result(timeout=10)
  assert 'authority' in outcome['error'],outcome
  assert not f.query('workspace_inventory')['workspaces'][0]['current_candidate']
  wait(lambda:next(x for x in f.query('snapshot')['attempts'] if x['id']==a['attempt'])['state']=='exited')
  print('actual_capture_retention_cancel_race_NO_AUTHORITATIVE_CANDIDATE_PASS',json.dumps(outcome),flush=True)
 finally:f.close()
def cleanup_crash(point):
 f=Fixture(point)
 try:
  a=f.admit('a');f.ready(a,'a');c=f.capture(a);f.stop_attempt(a);f.terminate(f.controller)
  f.env.update(CORENIUS_TEST_GIT_CRASH_POINT=point,CORENIUS_TEST_GIT_CRASH_MARKER=str(f.r/'crash'));f.controller=f.start_controller('controller-cleanup-armed')
  (f.r/'crash').write_text('declared owned cleanup crash');revision=f.query('snapshot')['revision']
  try:f.command('retire_workspace',{'attempt':a['attempt'],'retire_refs':['refs/heads/attempt']},key='cleanup-crash',revision=revision)
  except (AssertionError,json.JSONDecodeError):pass
  wait(lambda:f.controller.poll()==81);observed=json.loads((f.r/'crash.observed').read_text());root=f.r/'workers'/a['attempt']
  assert root.exists()==(point=='before_workspace_cleanup')
  f.controller=f.start_controller('controller-cleanup-recovered')
  result=f.command('retire_workspace',{'attempt':a['attempt'],'retire_refs':['refs/heads/attempt']},key='cleanup-crash',revision=revision)
  assert result['state']=='retired' and not root.exists() and result['operation']==observed['operation']
  assert f.query('workspace_inventory')['workspaces'][0]['cleanup_disposition']=='retired'
  print('actual_identity_fenced_cleanup_same_operation_recovery_PASS',json.dumps({'point':point,'operation':observed,'outcome':result}),flush=True)
 finally:f.close()
def crash(point,divergence=False):
 f=Fixture(point+('-divergence' if divergence else ''))
 try:
  a=f.admit('a');C=f.ready(a,'a');c=f.capture(a);v,_=f.accept(c)
  f.terminate(f.controller);f.env.update(CORENIUS_TEST_GIT_CRASH_POINT=point,CORENIUS_TEST_GIT_CRASH_MARKER=str(f.r/'crash'))
  f.controller=f.start_controller('controller-armed');(f.r/'crash').write_text('owned crash boundary')
  try:f.command('land_candidate',{'candidate':c['candidate'],'expected_trunk':f.base},key='crash-land')
  except (AssertionError,json.JSONDecodeError):pass
  wait(lambda:f.controller.poll()==81);observation=json.loads((f.r/'crash.observed').read_text());actual=git(f.r/'canonical','rev-parse','refs/heads/protected')
  assert actual==(f.base if point=='before_ref_update' else C)
  if divergence:
   # This is a deliberate write to the test's unique canonical fixture only.
   (f.r/'seed/divergence').write_text('unexplained fixture ref change');git(f.r/'seed','add','divergence');git(f.r/'seed','-c','user.name=Fixture','-c','user.email=fixture@invalid','commit','-m','unexplained divergence')
   changed=git(f.r/'seed','rev-parse','HEAD');git(f.r/'seed','push',str(f.r/'canonical'),changed+':refs/heads/protected')
  f.controller=f.start_controller('controller-recovered');snapshot=f.query('snapshot');ops=[o for o in snapshot['operations'] if o['id']==observation['operation']];assert len(ops)==1
  if divergence:
   assert ops[0]['state']=='unknown' and git(f.r/'canonical','rev-parse','refs/heads/protected')==changed
   f.command('create_task',{'task':'b','work_ref':{'deployment':'fixture','project':'p','item':'b'},'source_revision':'r1','brief':'b'})
   assert f.command('admit',{'task':'b'},allow_error=True).get('error')
   assert f.query('workspace_inventory')['ref_drift']
  else:
   assert ops[0]['state']=='confirmed' and snapshot['project']['base']==C and git(f.r/'canonical','rev-parse','refs/heads/protected')==C
  print('actual_journaled_conditional_ref_recovery_PASS',json.dumps({'point':point,'divergence':divergence,'observed_operation':observation,'protected_ref_before_restart':actual,'operations':ops}),flush=True)
  f.stop_attempt(a)
 finally:f.close()
def bounded_output():
 f=Fixture('bounded-output')
 try:
  a=f.admit('a');f.ready(a,'a',flood=True);c=f.capture(a)
  v=f.command('verify_candidate',{'candidate':c['candidate']});assert v['verdict']=='fail',v
  evidence=f.query('candidate_evidence',{'candidate':c['candidate']});assert f.command('accept_candidate',{'candidate':c['candidate'],'verification':v['verification']},allow_error=True).get('error')
  print('actual_fixed_verifier_output_bound_FAIL_CLOSED_PASS',json.dumps({'verification':v,'candidate_evidence':evidence}),flush=True)
  f.stop_attempt(a)
 finally:f.close()
if __name__=='__main__':
 modes=os.environ.get('CORENIUS_TEST_GIT_MODES','normal,before_ref_update,after_ref_update,divergence,hostile,bounded-output,cancel,before_workspace_cleanup,after_workspace_cleanup').split(',')
 for mode in modes:
  if mode=='normal':normal()
  elif mode=='hostile':hostile()
  elif mode=='bounded-output':bounded_output()
  elif mode=='cancel':cancel_race()
  elif mode in ['before_workspace_cleanup','after_workspace_cleanup']:cleanup_crash(mode)
  elif mode=='divergence':crash('before_ref_update',True)
  else:crash(mode)
