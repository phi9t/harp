use corenius_sqlite_controller::Controller;
use serde_json::json;
#[test]
fn workspace_inventory_is_an_authenticated_controller_projection() {
 let r=tempfile::tempdir().unwrap();
 let c=Controller::open(r.path().join("state.db"),"operator-git-secret").unwrap();
 let response=c.handle(json!({"auth":{"principal":"operator","token":"operator-git-secret"},"project":"p","query":{"kind":"workspace_inventory","args":{}}}));
 assert!(response.is_ok(),"workspace inventory must be a supported authenticated projection: {response:?}");
}
