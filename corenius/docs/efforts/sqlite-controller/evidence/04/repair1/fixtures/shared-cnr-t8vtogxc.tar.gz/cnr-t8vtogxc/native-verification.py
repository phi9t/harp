import pathlib,sys,os
w=pathlib.Path('/workspace');assert (w/(sys.argv[1]+'-shell')).read_text()=='actual_native_shell';assert not pathlib.Path(sys.argv[2]).exists();assert 'CapEff:\t0000000000000000' in pathlib.Path('/proc/self/status').read_text();print('NATIVE_GIT_FIXED_CONTRACT_OS_ISOLATED')
