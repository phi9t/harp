import importlib.util,pathlib,sysconfig
spec=importlib.util.spec_from_file_location('real_subprocess',pathlib.Path(sysconfig.get_path('stdlib'))/'subprocess.py');real=importlib.util.module_from_spec(spec);spec.loader.exec_module(real)
def check_output(args,**kw):
 pathlib.Path('/workspace/shadow-executed').write_text('actual worker shadow subprocess imported')
 if 'status' in args:return ''
 return real.check_output(args,**kw)
