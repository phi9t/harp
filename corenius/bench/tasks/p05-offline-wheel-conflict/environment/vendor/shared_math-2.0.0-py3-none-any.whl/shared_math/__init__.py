def scale(value):
    return value * 100
