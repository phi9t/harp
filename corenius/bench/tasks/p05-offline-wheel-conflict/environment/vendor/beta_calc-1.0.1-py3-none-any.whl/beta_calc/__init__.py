from shared_math import scale

def beta_score(value):
    return scale(value) + 2
